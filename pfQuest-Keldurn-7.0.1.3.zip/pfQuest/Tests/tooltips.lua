-- Run from the pfQuest folder with Lua 5.0: lua Tests/tooltips.lua
-- Optional first argument selects an older addon folder for regression checks.
local root = arg and arg[1] or "."
local f = assert(io.open(root.."/map.lua"))
local source = f:read("*a"); f:close()
local first = assert(string.find(source, 'pfMap.tooltip = CreateFrame(', 1, true))
local last = assert(string.find(source, 'function pfMap:GetMapNameByID(', first, true))
local globals, clock, zone, focus = getfenv(0), 10, 1, nil
local reads, kills, pelts = 0, 2, 1
function getglobal(name) return globals[name] end
function GetTime() return clock end
function GetMouseFocus() return focus end
function GetCurrentMapContinent() return 1 end
function GetCurrentMapZone() return zone end
strfind, strsub = string.find, string.sub
QUEST_MONSTERS_KILLED, QUEST_OBJECTS_FOUND = "(.*): (%d+)/(%d+)", "(.*): (%d+)/(%d+)"
pfUI = {api = {SanitizePattern = function(pattern) return pattern end}}
pfQuest_config = {}
pfQuest_Loc = setmetatable({}, {__index = function(_, key) return key end})
pfQuestCompat = {GetQuestLogTitle = function(id)
  return id == 1 and "Wolf Hunt" or "Warm Cloaks"
end}
function GetNumQuestLogEntries() reads = reads + 1; return 2 end
function GetNumQuestLeaderBoards() return 1 end
function GetQuestLogLeaderBoard(_, id)
  if id == 1 then return "Forest Wolf: "..kills.."/5", "monster", false end
  return "Wolf Pelt: "..pelts.."/3", "item", false
end
function CreateFrame()
  return {scripts = {}, SetScript = function(self, event, callback) self.scripts[event] = callback end}
end
GameTooltip = {count = 0, visible = false, reenterShow = false}
function GameTooltip:NumLines() return self.count end
function GameTooltip:IsShown() return self.visible end
function GameTooltip:AddLine(text)
  self.count = self.count + 1
  local name = "GameTooltipTextLeft"..self.count
  globals[name] = globals[name] or {GetText = function(self) return self.text end}
  globals[name].text = text
end
function GameTooltip:Show()
  local opening = not self.visible
  self.visible = true
  if opening or self.reenterShow then pfMap.tooltip.scripts.OnShow() end
end
function GameTooltip:Hide()
  self.visible = false
  if pfMap.tooltip.scripts.OnHide then pfMap.tooltip.scripts.OnHide() end
end
function GameTooltip:Rebuild(name, extra)
  -- Native tooltips reuse font strings; inactive lines retain their old text.
  self.count = 0
  self:AddLine(name)
  self:AddLine("Level 12 Beast")
  for i=1,extra or 0 do self:AddLine("Native detail "..i) end
end
local function meta(quest, spawn, item, rate)
  return {quest = quest, spawn = spawn, item = item and {item} or {}, droprate = rate}
end
pfMap = {tooltips = {
  ["Forest Wolf"] = {
    hunt = {[1] = meta("Wolf Hunt", "Forest Wolf"), [2] = meta("Distant Wolves", "Forest Wolf")},
    pelts = {[1] = meta("Warm Cloaks", "Forest Wolf", "Wolf Pelt", "25")},
    loot = {[1] = meta(nil, "Forest Wolf", "Sharp Claw", "50")},
  },
  ["Black Bear"] = {bear = {[1] = meta("Bear Patrol", "Black Bear")}},
}, GetMapID = function(_, continent, map) return map end}
assert(loadstring("local compat = pfQuestCompat\n"..string.sub(source, first, last-1)))()
local function tick(dt)
  clock = clock + (dt or .1)
  if pfMap.tooltip.scripts.OnUpdate then pfMap.tooltip.scripts.OnUpdate() end
end
local function contains(text)
  for line=1,GameTooltip.count do
    if string.find(getglobal("GameTooltipTextLeft"..line):GetText(), text, 1, true) then return true end
  end
end
local function assertWolf()
  assert(contains("Wolf Hunt") and contains("Forest Wolf: "..kills.."/5"), "kill quest lines are missing")
  assert(contains("Warm Cloaks") and contains("Wolf Pelt: "..pelts.."/3"), "quest drop progress is missing")
  assert(contains("25%") and contains("Sharp Claw") and contains("50%"), "drop information is missing")
end

GameTooltip:Rebuild("Forest Wolf"); GameTooltip:Show(); assertWolf()
local augmented = GameTooltip:NumLines()
-- Quick re-hover during FadeOut never makes the tooltip frame fully hidden.
GameTooltip:Rebuild("Forest Wolf"); tick()
assert(contains("Wolf Hunt"), "quick re-hover lost quest/drop lines while the tooltip stayed visible")
assertWolf()
assert(GameTooltip:NumLines() == augmented, "re-hover duplicated extra lines")
for i=1,100 do
  GameTooltip:Rebuild("Forest Wolf"); tick(.06); assertWolf()
  assert(GameTooltip:NumLines() == augmented, "repeated re-hover accumulated extra lines")
end

local before = reads
for i=1,100 do tick() end
assert(reads == before and GameTooltip:NumLines() == augmented, "unchanged hover rescanned quests or duplicated lines")
GameTooltip:AddLine("Another addon's information"); tick()
assert(reads == before and GameTooltip:NumLines() == augmented + 1 and contains("Another addon's information"),
  "refresh overwrote another addon or duplicated existing lines")
-- A rebuilt native tooltip can have as many base rows as our previous total.
GameTooltip:Rebuild("Forest Wolf", augmented - 2); tick(); assertWolf()
assert(GameTooltip:NumLines() == augmented*2 - 2, "same-length native rebuild was mistaken for augmented content")

kills, pelts = 3, 2
GameTooltip:Rebuild("Forest Wolf"); tick(); assertWolf()
GameTooltip:Rebuild("Black Bear"); tick()
assert(contains("Bear Patrol") and not contains("Wolf Hunt") and not contains("Sharp Claw"), "switching enemies kept stale information")
GameTooltip:Rebuild("Unrelated Enemy"); tick()
assert(GameTooltip:NumLines() == 2, "unrelated enemy received stale quest lines")
GameTooltip:Rebuild("|cffff0000Forest Wolf|r"); tick(); assertWolf()

zone = 2
GameTooltip:Rebuild("Forest Wolf"); tick()
assert(contains("Distant Wolves") and not contains("Warm Cloaks"), "zone filtering was lost")
zone = 1
GameTooltip:Rebuild("Forest Wolf"); tick(); assertWolf()
pfQuest_config.showtooltips = "0"
GameTooltip:Rebuild("Forest Wolf"); tick()
assert(GameTooltip:NumLines() == 2, "disabled tooltips still gained extra lines")
pfQuest_config.showtooltips = "1"; tick(); assertWolf()

focus = {title = "Map node"}
GameTooltip:Rebuild("Forest Wolf"); tick()
assert(GameTooltip:NumLines() == 2, "map node tooltip gained duplicate world-hover information")
focus = {GetName = function() return "QuestTimer1" end}
GameTooltip:Rebuild("Forest Wolf"); tick()
assert(GameTooltip:NumLines() == 2, "quest timer exclusions were lost")
focus = nil
-- Guard reentrant Show callbacks, while retaining normal hide/show behavior.
GameTooltip.reenterShow = true
GameTooltip:Rebuild("Forest Wolf"); tick(); assertWolf()
assert(GameTooltip:NumLines() == augmented, "reentrant Show accumulated extra lines")
GameTooltip.reenterShow = false
GameTooltip:Hide(); before = reads; tick()
assert(reads == before and not GameTooltip:IsShown(), "hidden tooltip was scanned or reopened")
GameTooltip:Rebuild("Forest Wolf"); GameTooltip:Show(); assertWolf()
GameTooltip:Hide(); GameTooltip.count = 0; GameTooltipTextLeft1.text = nil; GameTooltip:Show()
GameTooltip:Rebuild("Forest Wolf"); tick(); assertWolf()
print("PASS: rapid re-hover, pooled lines, stable-hover scan budget, duplicate prevention, other addons, native rebuilds, quest progress, enemy/zone changes, exclusions, recursion and hide/show.")
