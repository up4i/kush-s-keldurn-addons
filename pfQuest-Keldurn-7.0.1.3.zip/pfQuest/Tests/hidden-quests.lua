-- Run from the pfQuest folder with Lua 5.0: lua Tests/hidden-quests.lua
-- Optional first argument selects an older addon folder for regression checks.
local root = arg and arg[1] or "."
local function source(path)
  local f = assert(io.open(root.."/"..path))
  local text = f:read("*a"); f:close(); return text
end
local function section(path, first, last, prefix)
  local text = source(path)
  local start = assert(string.find(text, first, 1, true))
  local finish = assert(string.find(text, last, start, true))
  assert(loadstring((prefix or "")..string.sub(text, start, finish-1)))()
end

-- Only the client APIs and frame objects are simulated; addon callbacks run as-is.
local methods = {}
local function noop() end
local frameMeta = { __index = function(_, key)
  return methods[key] or (string.find(key, "^[A-Z]") and noop or nil)
end }
function CreateFrame(_, name, parent)
  local f = setmetatable({scripts = {}, name = name, parent = parent,
    height = 20, width = 200, text = "", visible = false}, frameMeta)
  if name then getfenv(0)[name] = f end
  return f
end
function methods:SetScript(event, callback) self.scripts[event] = callback end
function methods:CreateTexture() return CreateFrame() end
function methods:CreateFontString() return CreateFrame() end
function methods:GetName() return self.name end
function methods:GetHeight() return self.height end
function methods:SetHeight(n) self.height = n end
function methods:SetWidth(n) self.width = n end
function methods:SetText(text) self.text = text end
function methods:GetStringWidth() return string.len(self.text)*6 end
function methods:Show() self.visible = true end
function methods:Hide() self.visible = false end
function methods:IsShown() return self.visible end
function methods:IsVisible() return self.visible end
function methods:GetPoint() return "TOPLEFT", self.parent, "TOPLEFT", 0, 0 end

local clock, selected, shifted = 20, 2, false
local entries = {
  {header = true, title = "First zone"},
  {id = 101, title = "Alpha", watched = true},
  {id = 102, title = "Beta"},
  {id = 103, title = "Gamma", watched = true},
}
local function title(index)
  local q = entries[index]
  if q then return q.title, 10, nil, q.header, nil, q.complete end
end
function GetBuildInfo() return "1.12.1", "5875", "", 11200 end
function GetTime() return clock end
function GetNumQuestLogEntries()
  local count = 0
  for _, q in ipairs(entries) do if not q.header then count = count + 1 end end
  return table.getn(entries), count
end
function GetQuestLogSelection() return selected end
function GetNumQuestLeaderBoards(index) return entries[index] and not entries[index].header and 1 or 0 end
function GetQuestLogLeaderBoard(_, index)
  return "Visit the location", "event", entries[index] and entries[index].done
end
function IsQuestWatched(index) return entries[index] and entries[index].watched end
function IsShiftKeyDown() return shifted end
function IsControlKeyDown() return false end
function UnitLevel() return 10 end
function IsEmpty(t) return not next(t) end
time = GetTime
ceil, min, max, strfind, gsub = math.ceil, math.min, math.max, string.find, string.gsub
GetQuestLink, RemoveQuestWatch, AddQuestWatch, AbandonQuest = noop, noop, noop, noop
QuestLog_Update, QuestLogTitleButton_OnClick, SetItemRef = noop, noop, noop
UIParent, WorldMapFrame, WorldMapButton = CreateFrame(), CreateFrame(), CreateFrame()
QuestLogDetailScrollChildFrame = CreateFrame()
pfQuest_Loc = setmetatable({}, {__index = function(_, key) return key end})
pfQuestCompat = {GetQuestLogTitle = title, QuestLogDescriptionTitle = CreateFrame(),
  GetDifficultyColor = function() return {r = 1, g = 1, b = 1} end, gfind = string.gfind}
pfUI = {font_default = "test", api = {emulated = true}}
pfQuestConfig = {path = "Interface\\AddOns\\pfQuest"}
StaticPopupDialogs, SlashCmdList = {}, {}
pfQuest_config = {trackingmethod = 1, questlogbuttons = "1", allquestgivers = "0",
  currentquestgivers = "0", spawncolors = "0"}
pfQuest_history, pfQuest_colors = {}, {}
pfDB = {quests = {loc = {}, data = {}}}
for id=101,105 do
  pfDB.quests.data[id] = {lvl = 10, obj = {U = {id}}}
end
pfDB.quests.loc = {[101] = {T = "Alpha"}, [102] = {T = "Beta"},
  [103] = {T = "Gamma"}, [104] = {T = "Delta"}, [105] = {T = "Epsilon"}}
pfDatabase = {localized = true}
function pfDatabase:GetQuestIDs(index)
  local q = entries[index]
  if q and q.id then return {q.id} end
end
pfMap = {nodes = {}, tooltips = {}, unifiedcache = {},
  tooltip = {GetColor = function() return 1,1,1 end},
  str2rgb = function() return 1,1,1 end}
function pfMap:ShowMapID() end
function pfDatabase:GetBestMap() return 1 end
function pfDatabase:SearchMobID(_, meta, maps)
  local node = {}
  for k, v in pairs(meta) do node[k] = v end
  node.title, node.layer = meta.quest, 0
  local addon = meta.addon or "PFDB"
  pfMap.nodes[addon] = pfMap.nodes[addon] or {}
  pfMap.nodes[addon][1] = pfMap.nodes[addon][1] or {}
  pfMap.nodes[addon][1][node.title.."|50"] = {[node.title] = node}
  maps[1] = true
  return maps
end
section("map.lua", "function pfMap:DeleteNode(", "function pfMap:NodeEnter(")
section("database.lua", "function pfDatabase:SearchQuestID(", "-- SearchQuest\n",
  "local quests = pfDB.quests.data; local compat = pfQuestCompat\n")
local function loadAddon()
  dofile(root.."/quest.lua")
  dofile(root.."/tracker.lua")
  pfQuest:AddQuestLogIntegration()
end
function pfMap:UpdateNodes()
  pfQuest.tracker.Reset()
  for _, nodes in pairs(self.nodes.PFQUEST and self.nodes.PFQUEST[1] or {}) do
    for title, node in pairs(nodes) do pfQuest.tracker.ButtonAdd(title, node) end
  end
end
local function refresh()
  event, this = "QUEST_LOG_UPDATE", pfQuest
  pfQuest.scripts.OnEvent()
  for i=1,80 do clock = clock + .1; pfQuest.scripts.OnUpdate() end
  assert(not next(pfQuest.queue), "quest queue did not settle")
  pfMap:UpdateNodes()
end
local function click(button)
  this, arg1 = button, "LeftButton"
  assert(button.scripts.OnClick)()
end
local function row(id)
  for index, q in ipairs(entries) do if q.id == id then return index end end
end
local function node(id, addon)
  local name = pfDB.quests.loc[id].T
  for _, nodes in pairs(pfMap.nodes[addon or "PFQUEST"] and pfMap.nodes[addon or "PFQUEST"][1] or {}) do
    if nodes[name] then return nodes[name] end
  end
end
local function button(id)
  for _, b in ipairs(pfQuest.tracker.buttons) do
    if not b.empty and b.questid == id and b.visible then return b end
  end
end

loadAddon(); refresh()
assert(node(101) and node(102) and node(103), "initial quests were not drawn")
selected = row(101); click(pfQuest.buttonHide)
selected = row(102); click(pfQuest.buttonHide)
assert(not node(101) and not node(102), "Hide failed to remove current markers")
-- Accepting a quest in another zone moves every existing quest-log row.
table.insert(entries, 1, {id = 104, title = "Delta"})
table.insert(entries, 1, {header = true, title = "New zone"})
refresh()
assert(not node(101) and not node(102), "accepting a quest restored hidden quest markers")
assert(not button(101) and not button(102), "watched dummy rows restored hidden quests")
assert(node(103) and node(104) and button(103) and button(104), "hiding old quests also hid new/visible quests")
assert(not next(pfQuest_history), "hiding incorrectly marked a quest completed")

entries[row(101)].done = true
refresh()
pfQuest:ResetAll(); refresh()
assert(not node(101) and not node(102), "objective/settings refresh forgot hidden choices")
-- SavedVariables are reloaded for this character before normal quest scanning.
local saved = pfQuest_config
pfMap.nodes = {}
loadAddon(); pfQuest_config = saved; refresh()
assert(not node(101) and not node(102), "reloading the addon forgot saved choices")
selected = row(101); click(pfQuest.buttonShow); refresh()
assert(node(101) and button(101) and not node(102), "Show did not restore only the selected quest")

-- All manual hiding controls use the same saved choice.
shifted, this, arg1 = true, button(103), "LeftButton"
pfQuest.tracker.ButtonClick(); shifted = false; refresh()
assert(not node(103) and not button(103), "tracker Shift-click was not retained")
local n = node(104)
shifted, this = true, {node = {[n.title] = n}, title = n.title, questid = 104, layer = 0}
pfMap:NodeClick(); shifted = false; refresh()
assert(not node(104), "map Shift-click was not retained")
pfDatabase:SearchQuestID(103, {addon = "PFDB"})
assert(node(103, "PFDB"), "manual hiding blocked independent database results")
click(pfQuest.buttonReset); refresh()
assert(node(101) and node(102) and node(103) and node(104), "explicit Reset failed to restore all quests")

click(pfQuest.buttonClean)
table.insert(entries, {id = 105, title = "Epsilon"})
refresh()
assert(not node(101) and not node(102) and not node(103) and not node(104) and node(105),
  "Clean hid a newly accepted quest or forgot existing choices")
dofile(root.."/slashcmd.lua"); SlashCmdList.PFDB("reset"); refresh()
assert(node(101) and node(105), "slash Reset failed to restore choices")

-- Hidden quests use identity rather than a server's display spelling.
entries[row(101)].title = "Server Alpha"
pfQuest:ResetAll(); refresh()
selected = row(101); click(pfQuest.buttonHide); refresh()
assert(not node(101) and not button(101), "server title alias bypassed the hidden quest ID")
pfQuest_config.trackingmethod = 2
pfQuest:ResetAll(); refresh()
assert(not node(101) and not node(105) and node(103), "tracked-only mode ignored hidden/unwatched choices")

local toc = source("pfQuest.toc")
assert(string.find(toc, "SavedVariablesPerCharacter: pfQuest_config", 1, true), "choices are not saved per character")
print("PASS: accepting/reordering quests, watched rows, progress/settings refresh, reload, Show/Reset/Clean, tracker/map hides, database queries, server aliases and tracked-only mode.")
