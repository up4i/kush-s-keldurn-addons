# pfQuest for Keldurn — compatibility fixes

Version: **7.0.1-Keldurn.3**. Based on Shagu's pfQuest 7.0.1; original credits, licence, databases, and translations are retained.

## Install

Close Keldurn and replace the existing `pfQuest` addon folder with the folder from this ZIP. The location is `%LOCALAPPDATA%\Keldurn\settings\AddOns`. Keep your saved settings. Restart Keldurn and enable pfQuest on the character screen. You can also use **AddOns → Install ZIP** there.

## What changed

- Quest and drop tooltip lines recover after quick re-hover or native tooltip rebuilds. The check runs only while the tooltip is visible, at most 20 times per second; unchanged contents skip quest scans. Existing lines from other addons are preserved and pfQuest avoids adding the same information repeatedly.
- Hidden quests are now saved by quest ID for each character. Accepting another quest, reordering the quest log, updating objectives, refreshing settings, or reloading the addon preserves those choices. Watched quest rows also respect them.
- **Hide** in the quest log and **Shift-click** on quest tracker rows or map markers remember the choice. **Clean** hides the quests currently in your log; newly accepted quests still appear normally. Independent database searches remain available.
- **Show** restores the selected quest. The quest-log **Reset** button or `/pfquest reset` restores all manually hidden quests. Changing display modes or other settings does not clear your choices.
- Minimap markers use a cached spatial index, so moving scans nearby markers instead of every marker in the zone. The index is rebuilt after quest/map data changes.
- Minimap refreshes run at most five times per second; moving route updates run at most four times per second. Stationary updates retain the original slower refresh behavior.
- The arrow updates at 20 Hz instead of on every rendered frame.
- Player route lines are not redrawn on a closed world map. Empty or disabled routes stop doing repeated work.
- Route-line previews are limited to the nearest 32 stops. All quest markers, quest data, and nearest-target tracking remain available; the preview updates as you move. This bounds the original quadratic route-planning work.
- `/pfquest perf` reports FPS, zone markers, and nearby candidates for troubleshooting.

Original commands such as `/pfquest config` remain available.

When upgrading from Keldurn.1, hide unwanted quests once to record them; that version did not save the choices. Choices already saved by Keldurn.2 carry over. Keep your existing saved settings and quest history.

## Check in game

Hover a quest enemy, quickly move the cursor away and back several times, and check that quest progress and drop information return each time without duplicate rows. Check both kill objectives and quest-item drops.

1. Hide two existing quests, including one that is watched.
2. Accept a quest in a different zone. The new quest should appear, while both hidden quests stay hidden on the tracker, map, and minimap.
3. Reload or restart Keldurn and check again. Use **Show** to restore one quest, or **Reset** to restore all.

Run through the same area that previously dropped to 10 FPS. If it still slows down, send `/pfquest perf` output while moving and say whether the world map, arrow, or minimap route lines are visible.

Offline Lua 5.0 checks verify tooltip rebuilds and rapid re-hover, duplicate prevention, hidden-quest refresh/reload behavior, manual controls, tracked-only mode, marker selection, and the existing movement optimizations. Run `lua Tests/tooltips.lua`, `lua Tests/hidden-quests.lua` and `lua Tests/performance.lua` from this addon folder. This build has not been tested inside a running Keldurn client, so live behavior and an actual FPS gain still need confirmation.
