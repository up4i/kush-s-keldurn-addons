--[[

Bar1 = ActionButton1-12
Bar2 = MultiBarBottomLeft
Bar3 = MultiBarBottomRight
Bar4 = MultiBarRight
Bar5 = MultiBarLeft
Bar6 = ShapeshiftButton1-10
Bar7 = PetActionButton1-10
Bar8 = Bags
Bar9 = MicroButtons
Bar10 = BonusActionButton1-12

]]--

StaticPopupDialogs["BARTENDER2CONFIRM"] = { text = "Reset ALL settings?", button1 = "Yes", button2 = "No", timeout = 0, whileDead = 1, OnAccept = function() Bartender:ResetALL() end}

Bartender = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceHook-2.0", "AceDB-2.0", "AceConsole-2.0", "AceModuleCore-2.0")
Bartender:RegisterDB("BarDB")
Bartender:SetModuleMixins("AceEvent-2.0")

Bartender.version = "2.0-Keldurn.2"
Bartender.date = "2026-10-09"

Bartender:RegisterDefaults('profile', BT2Defaults )

local _G = getfenv(0)
local DBVersion = "Bar2DB-2"
local petTokenTextures = {
	PET_ATTACK_TEXTURE = "Interface\\Icons\\Ability_GhoulFrenzy",
	PET_FOLLOW_TEXTURE = "Interface\\Icons\\Ability_Tracking",
	PET_WAIT_TEXTURE = "Interface\\Icons\\Spell_Nature_TimeStop",
	PET_PASSIVE_TEXTURE = "Interface\\Icons\\Ability_Seal",
	PET_DEFENSIVE_TEXTURE = "Interface\\Icons\\Ability_Defend",
	PET_AGGRESSIVE_TEXTURE = "Interface\\Icons\\Ability_Racial_BloodRage",
	PET_DISMISS_TEXTURE = "Interface\\Icons\\Spell_Shadow_Teleport",
}

function Bartender:OnEnable()
	self:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
	self:Hook("ActionButton_ShowGrid")
	self:Hook("ActionButton_HideGrid")
	self:Hook("MultiActionBar_ShowAllGrids")
	self:Hook("MultiActionBar_HideAllGrids")
	self:Hook("UpdateTalentButton")
	self:Hook("MainMenuBar_UpdateKeyRing")
	self:Hook("MultiActionBar_Update")
	self:RegisterEvent("PLAYER_ENTERING_WORLD")
	self:RegisterEvent("UNIT_PET", "RefreshPetBar")
	self:RegisterEvent("PET_BAR_UPDATE", "RefreshPetBar")
	if type(PetActionBar_Update) == "function" then self:Hook("PetActionBar_Update") end
	self:MakeFrames()
	self:OnProfileEnable()
	self:ScheduleEvent(self.EnableAllBars, 10.0, self);
	self:Print("How may I serve you?")
end

function Bartender:EnableAllBars()
	SHOW_MULTI_ACTIONBAR_1 = 1
	SHOW_MULTI_ACTIONBAR_2 = 1
	SHOW_MULTI_ACTIONBAR_3 = 1
	SHOW_MULTI_ACTIONBAR_4 = 1
	MultiActionBar_Update()
	SetActionBarToggles(1,1,1,1)
end

function Bartender:OnProfileEnable()
	if self.binding then self:FinishBinding(false) end
	self:AllowMoving()
	if not self.db.profile.Extra[DBVersion] then
		self:ResetALL()
	end
	self:SetAllParents()
	self:SetupBars()
	self:ButtonHideCheck()
	self:ButtonScaleCheck()
	self:ButtonHotKeyCheck()
	self:ButtonAlphaCheck()
	self:ButtonNoCustomPositionCheck()
	self:ButtonZoomCheck()
	self:LoadAllPositions()
	self:UPDATE_BONUS_ACTIONBAR()
	MainMenuBar:Hide()
	MultiActionBar_Update()
	self:HideNormalTexture()
	self:RefreshPetBar()
end

-- Native multi-bar updates may put their containers back in Blizzard's layout.
-- Reapply button geometry without changing a bar's current or saved position.
function Bartender:MultiActionBar_Update()
	self.hooks["MultiActionBar_Update"].orig()
	if Bar1 then
		self:SetAllParents()
		self:SetupBars()
	end
end

function Bartender:PLAYER_ENTERING_WORLD()
	self:EnableAllBars()
	self:RepairLayout()
end

function Bartender:RepairLayout()
	self:SetAllParents()
	self:SetupBars()
	self:ButtonHideCheck()
	self:UPDATE_BONUS_ACTIONBAR()
	self:RefreshPetBar()
end

function Bartender:PetActionBar_Update()
	local ok, message = pcall(self.hooks["PetActionBar_Update"].orig)
	if not ok and not self.petUpdateErrorReported then
		self.petUpdateErrorReported = true
		self:Print("Native pet update failed: "..tostring(message))
	end
	self:UpdatePetBarVisibility()
end

function Bartender:RefreshPetBar()
	if not Bar7 then return end
	if type(PetActionBar_Update) == "function" then PetActionBar_Update() end
	self:UpdatePetBarVisibility()
end

function Bartender:UpdatePetBarVisibility()
	if not Bar7 or type(GetPetActionInfo) ~= "function" then return end
	local hasPet = UnitExists("pet") or (type(PetHasActionBar) == "function" and PetHasActionBar())
	local parent = PetActionBarFrame or Bar7
	if PetActionBarFrame then
		-- Bartender owns the position; native sliding can hide the container.
		PetActionBarFrame.mode = "none"
		if hasPet then PetActionBarFrame:Show() else PetActionBarFrame:Hide() end
	end
	if self.db.profile.Bar7.Hide then Bar7:Hide() else Bar7:Show() end
	self:SetupBar7()
	for i=1,10 do
		local button = _G["Bar7Button"..i]
		local icon = _G["Bar7Button"..i.."Icon"]
		local name, subtext, texture, isToken = GetPetActionInfo(i)
		button:SetParent(parent)
		if hasPet and name then
			button:Show()
			button.tooltipName = isToken and (_G[name] or name) or name
			button.tooltipSubtext = subtext
			button.isToken = isToken
			if icon then
				if isToken and texture then texture = _G[texture] or petTokenTextures[texture] or texture end
				if texture then icon:SetTexture(texture) icon:Show() else icon:Hide() end
			end
		else
			button:Hide()
		end
	end
end

function Bartender:OnDisable()
	if self.binding then self:FinishBinding(false) end
	if PetActionBarFrame and self.petUpdateSaved then
		PetActionBarFrame:SetScript("OnUpdate", self.petOriginalUpdate)
	end
end

function Bartender:AllowMoving()
	MultiBarLeft:ClearAllPoints()
	MultiBarRight:ClearAllPoints()
	MultiBarBottomLeft:ClearAllPoints()
	MultiBarBottomRight:ClearAllPoints()
	for i,v in ipairs(AllButtons) do v:ClearAllPoints() end
end

function Bartender:MakeFrames()
	for i=1,10 do
		self:CreateFrame("Bar"..i)
	end
end

function Bartender:DefaultBars()
	for i=1,10 do
		_G["Bar"..i]:ClearAllPoints()
		_G["Bar"..i]:Show()
		_G["Bar"..i]:SetScale(1)
	end
	for i=1,12 do
		_G["Bar1Button"..i]:SetAlpha(1)
		_G["Bar2Button"..i]:SetAlpha(1)
		_G["Bar3Button"..i]:SetAlpha(1)
		_G["Bar4Button"..i]:SetAlpha(1)
		_G["Bar5Button"..i]:SetAlpha(1)
		_G["Bar10Button"..i]:SetAlpha(1)
	end
	for i=1,10 do
		_G["Bar6Button"..i]:SetAlpha(1)
		_G["Bar7Button"..i]:SetAlpha(1)
	end
	for i=1,5 do
		_G["Bar8Button"..i]:SetAlpha(1)
	end
	for i=1,8 do
		_G["Bar9Button"..i]:SetAlpha(1)
	end
	Bar1:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, -5)
	Bar2:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, 31)
	Bar3:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, 67)
	Bar4:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -41, 100)
	Bar5:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -77, 100)
	Bar6:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 20, 110)
	Bar7:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 20, 140)
	Bar8:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -190, 30)
	Bar9:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -205, -5)
	Bar10:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, -5)
	self.db.profile.Extra[DBVersion] = true
end

function Bartender:SetAllParents()
	for i=1,12 do
		_G["Bar1Button"..i]:SetParent(Bar1)
		_G["Bar10Button"..i]:SetParent(Bar10)
	end
	local containers = { MultiBarBottomLeft, MultiBarBottomRight, MultiBarRight, MultiBarLeft }
	for n, container in ipairs(containers) do
		local bar = _G["Bar"..(n + 1)]
		container:SetParent(bar)
		container:ClearAllPoints()
		container:SetPoint("TOPLEFT", bar, "TOPLEFT", 0, 0)
		for i=1,12 do
			_G[bar:GetName().."Button"..i]:SetParent(container)
		end
	end
	for i=1,10 do
		_G["Bar6Button"..i]:SetParent(Bar6)
		_G["Bar7Button"..i]:SetParent(PetActionBarFrame or Bar7)
	end
	if PetActionBarFrame then
		PetActionBarFrame:SetParent(Bar7)
		if not self.petUpdateSaved then
			if type(PetActionBarFrame.GetScript) == "function" then
				self.petOriginalUpdate = PetActionBarFrame:GetScript("OnUpdate")
			end
			self.petUpdateSaved = true
		end
		PetActionBarFrame:SetScript("OnUpdate", nil)
	end
	for i=1,5 do
		_G["Bar8Button"..i]:SetParent(Bar8)
	end
	for i=1,8 do
		_G["Bar9Button"..i]:SetParent(Bar9)
	end
	KeyRingButton:SetParent(UIParent)
end

function Bartender:SetupBars()
	for i=1,10 do
		self["SetupBar"..i](self)
	end
end

-- for bars 1-5 + 10
function Bartender:SetupActionBars(bar)
	local BarString = bar:GetName()
	local Rows = self.db.profile[BarString].Rows or 1
	if Rows ~= 1 and Rows ~= 2 and Rows ~= 3 and Rows ~= 4 and Rows ~= 6 and Rows ~= 12 then
		Rows = BT2Defaults[BarString].Rows
	end
	local ButtonPerRow = 12 / Rows
	local Padding = self.db.profile[BarString].Padding or -1
	bar:SetWidth(36 * ButtonPerRow + ((ButtonPerRow - 1) * Padding) + 8)
	bar:SetHeight(36 * Rows + ((Rows - 1) * Padding) + 8)
	for i=1,12 do
		local button = _G[BarString.."Button"..i]
		local row = math.floor((i - 1) / ButtonPerRow)
		local column = (i - 1) - row * ButtonPerRow
		button:SetWidth(36)
		button:SetHeight(36)
		button:ClearAllPoints()
		-- BarXButtonN is a Lua alias, not the native button's registered name.
		-- Use the owning frame object and explicit offsets, never alias strings.
		button:SetPoint("TOPLEFT", bar, "TOPLEFT", 5 + column * (36 + Padding), -3 - row * (36 + Padding))
	end
	local containers = { Bar2 = MultiBarBottomLeft, Bar3 = MultiBarBottomRight, Bar4 = MultiBarRight, Bar5 = MultiBarLeft }
	local container = containers[BarString]
	if container then
		container:ClearAllPoints()
		container:SetPoint("TOPLEFT", bar, "TOPLEFT", 0, 0)
		container:SetWidth(bar:GetWidth())
		container:SetHeight(bar:GetHeight())
	end
end

function Bartender:SetupBar1()
	self:SetupActionBars(Bar1)
end

function Bartender:SetupBar2()
	self:SetupActionBars(Bar2)
end

function Bartender:SetupBar3()
	self:SetupActionBars(Bar3)
end

function Bartender:SetupBar4()
	self:SetupActionBars(Bar4)
end

function Bartender:SetupBar5()
	self:SetupActionBars(Bar5)
end

function Bartender:SetupSmallBar(bar, count, size, micro)
	local name = bar:GetName()
	local profile = self.db.profile[name]
	local pad = profile.Padding or 0
	local x, y = 5, 5
	local width, height = 0, 0
	if micro then x, y = 3, 4 end
	for i=1,count do
		local button = _G[name.."Button"..i]
		local w, h = size or button:GetWidth(), size or button:GetHeight()
		if not w or w <= 0 then w = 30 end
		if not h or h <= 0 then h = 30 end
		if size then button:SetWidth(w) button:SetHeight(h) end
		button:ClearAllPoints()
		button:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", x, y)
		width = math.max(width, x + w)
		height = math.max(height, y + h)
		if profile.Swap then
			-- Micro buttons include a 21px transparent upper margin.
			y = y + h + pad - (micro and 21 or 0)
		else
			x = x + w + pad
		end
	end
	bar:SetWidth(width + 3)
	bar:SetHeight(height + 3)
end

function Bartender:SetupBar6() self:SetupSmallBar(Bar6, 10, 30) end
function Bartender:SetupBar7()
	self:SetupSmallBar(Bar7, 10, 30)
	if PetActionBarFrame then
		PetActionBarFrame:ClearAllPoints()
		PetActionBarFrame:SetPoint("BOTTOMLEFT", Bar7, "BOTTOMLEFT", 0, 0)
		PetActionBarFrame:SetWidth(Bar7:GetWidth())
		PetActionBarFrame:SetHeight(Bar7:GetHeight())
	end
end
function Bartender:SetupBar8() self:SetupSmallBar(Bar8, 5) end
function Bartender:SetupBar9() self:SetupSmallBar(Bar9, 8, nil, true) end

function Bartender:SetupBar10()
	self:SetupActionBars(Bar10)
end

function Bartender:ButtonHideCheck()
	for i=1,10 do
		if self.db.profile["Bar"..i].Hide then _G["Bar"..i]:Hide() end
	end
end

function Bartender:ButtonScaleCheck()
	for i=1,10 do
		_G["Bar"..i]:SetScale(self.db.profile["Bar"..i].Scale)
	end
end

function Bartender:ButtonHotKeyCheck()
	for i=1,12 do
		if self.db.profile.Bar1.HideHotKey then _G["Bar1Button"..i.."HK"]:Hide() end
		if self.db.profile.Bar2.HideHotKey then _G["Bar2Button"..i.."HK"]:Hide() end
		if self.db.profile.Bar3.HideHotKey then _G["Bar3Button"..i.."HK"]:Hide() end
		if self.db.profile.Bar4.HideHotKey then _G["Bar4Button"..i.."HK"]:Hide() end
		if self.db.profile.Bar5.HideHotKey then _G["Bar5Button"..i.."HK"]:Hide() end
		if self.db.profile.Bar10.HideHotKey then _G["Bar10Button"..i.."HK"]:Hide() end
	end
end

function Bartender:ButtonAlphaCheck()
	for i=1,12 do
		_G["Bar1Button"..i]:SetAlpha(self.db.profile.Bar1.Alpha)
		_G["Bar2Button"..i]:SetAlpha(self.db.profile.Bar2.Alpha)
		_G["Bar3Button"..i]:SetAlpha(self.db.profile.Bar3.Alpha)
		_G["Bar4Button"..i]:SetAlpha(self.db.profile.Bar4.Alpha)
		_G["Bar5Button"..i]:SetAlpha(self.db.profile.Bar5.Alpha)
		_G["Bar10Button"..i]:SetAlpha(self.db.profile.Bar10.Alpha)
	end
	for i=1,10 do
		_G["Bar6Button"..i]:SetAlpha(self.db.profile.Bar6.Alpha)
		_G["Bar7Button"..i]:SetAlpha(self.db.profile.Bar7.Alpha)
	end
	for i=1,5 do
		_G["Bar8Button"..i]:SetAlpha(self.db.profile.Bar8.Alpha)
	end
	for i=1,8 do
		_G["Bar9Button"..i]:SetAlpha(self.db.profile.Bar9.Alpha)
	end
end

function Bartender:ButtonNoCustomPositionCheck()
	for i=1,10 do
		local bar = _G["Bar"..i]
		local profile = self.db.profile["Bar"..i]
		if not profile.PosX or not profile.PosY then self:ResetPosition(bar) end
	end
end

function Bartender:ButtonZoomCheck()
	if self.db.profile.Extra.HideBorder then
		for i,v in ipairs(AllIcons) do v:SetTexCoord(0.07,0.93,0.07,0.93) end
	else
		for i,v in ipairs(AllIcons) do v:SetTexCoord(0,1,0,1) end
	end
end

function Bartender:LoadAllPositions()
	for i=1,10 do
		if self.db.profile["Bar"..i].PosX and self.db.profile["Bar"..i].PosY then self:LoadPosition(_G["Bar"..i]) end
	end
end

function Bartender:CreateFrame(name, text)
	if not name then return end
	local frame = CreateFrame("Button", name, UIParent)
	frame:EnableMouse(false)
	frame:SetMovable(true)
	frame:RegisterForDrag("LeftButton")
	frame:SetWidth(10)
	frame:SetHeight(10)
	frame:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", tile = true, tileSize = 16, edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16, insets = {left = 5, right = 3, top = 3, bottom = 5},})
	frame:ClearAllPoints()
	frame:SetBackdropColor(0, 0, 0, 0)
	frame:SetBackdropBorderColor(0.5, 0.5, 0, 0)
	frame:SetPoint("CENTER", "UIParent", "CENTER", 0, 0)
	frame.Text = frame:CreateFontString(nil, "ARTWORK")
	frame.Text:SetFontObject(GameFontNormal)
	frame.Text:SetText(text)
	frame.Text:Show()
	frame.Text:ClearAllPoints()
	frame.Text:SetPoint("CENTER", frame, "CENTER",0,0)
end

function Bartender:SavePosition(arg1)
	if not arg1 then return end
	local frame = arg1:GetName()
	local x,y = arg1:GetLeft(), arg1:GetBottom()
	local s = arg1:GetEffectiveScale()
	x,y = x*s,y*s
	self.db.profile[frame].PosX = x
	self.db.profile[frame].PosY = y
end

function Bartender:LoadPosition(arg1)
	if not arg1 then return end
	local frame = arg1:GetName()
	local x = self.db.profile[frame].PosX
	local y = self.db.profile[frame].PosY
	if ((not x) or (not y)) then return end
	local s = arg1:GetEffectiveScale()
	x,y = x/s,y/s
	arg1:ClearAllPoints()
	arg1:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x, y)
end

function Bartender:HideBar(arg1)
	self.db.profile[arg1:GetName()].Hide = true
	arg1:Hide()
end

function Bartender:ShowBar(arg1)
	self.db.profile[arg1:GetName()].Hide = nil
	arg1:Show()
	if arg1 == Bar7 then self:RefreshPetBar() end
end

function Bartender:HideBorder()
	self.db.profile.Extra.HideBorder = true
	self:ButtonZoomCheck()
end

function Bartender:ShowBorder()
	self.db.profile.Extra.HideBorder = nil
	self:ButtonZoomCheck()
end

function Bartender:SwapOff(arg1)
	self.db.profile[arg1:GetName()].Swap = false
	self["Setup"..arg1:GetName()](self)
end

function Bartender:SwapOn(arg1)
	self.db.profile[arg1:GetName()].Swap = true
	self["Setup"..arg1:GetName()](self)
end

function Bartender:Rows(arg1,arg2)
	self.db.profile[arg1:GetName()].Rows = 12 /  math.floor(12 / arg2)
	self["Setup"..arg1:GetName()](self)
end

function Bartender:ShowHK(arg1)
	self.db.profile[arg1:GetName()].HideHotKey = nil
	for i=1,12 do
		_G[arg1:GetName().."Button"..i.."HK"]:Show()
	end
end

function Bartender:HideHK(arg1)
	self.db.profile[arg1:GetName()].HideHotKey = true
	for i=1,12 do
		_G[arg1:GetName().."Button"..i.."HK"]:Hide()
	end
end

function Bartender:Scale(arg1,arg2)
	arg1:SetScale(arg2)
	self.db.profile[arg1:GetName()].Scale = arg2	
	self:LoadPosition(arg1)
end

function Bartender:Alpha(arg1,arg2)
	if self.unlock then
		self:Print("Please lock your bars first")
		return
	elseif ((arg1 == Bar1) or (arg1 == Bar2) or (arg1 == Bar3) or (arg1 == Bar4) or (arg1 == Bar5) or (arg1 == Bar10)) then
		for i=1,12 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(arg2)
		end
		self.db.profile[arg1:GetName()].Alpha = arg2	
	elseif ((arg1 == Bar6) or (arg1 == Bar7)) then
		for i=1,10 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(arg2)
		end
		self.db.profile[arg1:GetName()].Alpha = arg2	
	elseif arg1 == Bar8 then
		for i=1,5 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(arg2)
		end
		self.db.profile[arg1:GetName()].Alpha = arg2	
	elseif arg1 == Bar9 then
		for i=1,8 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(arg2)
		end
		self.db.profile[arg1:GetName()].Alpha = arg2	
	end
end

function Bartender:Padding(arg1,arg2)
	self.db.profile[arg1:GetName()].Padding = arg2
	self["Setup"..arg1:GetName()](self)
end

function Bartender:ResetPadding(arg1)
	self.db.profile[arg1:GetName()].Padding = nil
	self["Setup"..arg1:GetName()](self)
end

function Bartender:ResetScale(arg1)
	arg1:SetScale(1)
	self.db.profile[arg1:GetName()].Scale = nil
	self:LoadPosition(arg1)
end

function Bartender:ResetAlpha(arg1)
	if self.unlock then
		self:Print("Please lock your bars first")
		return
	elseif ((arg1 == Bar1) or (arg1 == Bar2) or (arg1 == Bar3) or (arg1 == Bar4) or (arg1 == Bar5) or (arg1 == Bar10)) then
		for i=1,12 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(1)
		end
		self.db.profile[arg1:GetName()].Alpha = nil
	elseif ((arg1 == Bar6) or (arg1 == Bar7)) then
		for i=1,10 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(1)
		end
		self.db.profile[arg1:GetName()].Alpha = nil
	elseif arg1 == Bar8 then
		for i=1,5 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(1)
		end
		self.db.profile[arg1:GetName()].Alpha = nil
	elseif arg1 == Bar9 then
		for i=1,8 do
			_G[arg1:GetName().."Button"..i]:SetAlpha(1)
		end
		self.db.profile[arg1:GetName()].Alpha = nil
	end
end

function Bartender:ResetPosition(arg1)
	self.db.profile[arg1:GetName()].PosX = nil
	self.db.profile[arg1:GetName()].PosY = nil
	arg1:ClearAllPoints()
	if arg1 == Bar1 then
		Bar1:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, -5)
	elseif arg1 == Bar2 then
		Bar2:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, 31)
	elseif arg1 == Bar3 then
		Bar3:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, 67)
	elseif arg1 == Bar4 then
		Bar4:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -41, 100)
	elseif arg1 == Bar5 then
		Bar5:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -77, 100)
	elseif arg1 == Bar6 then
		Bar6:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 20, 110)
	elseif arg1 == Bar7 then
		Bar7:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", 20, 140)
	elseif arg1 == Bar8 then
	    Bar8:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -190, 30)
	elseif arg1 == Bar9 then
	    Bar9:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMRIGHT", -205, -5)
	elseif arg1 == Bar10 then
		Bar10:SetPoint("BOTTOMLEFT", "UIParent", "BOTTOMLEFT", -5, -5)
	end
end

function Bartender:ResetBar(arg1)
	if self.unlock then
		self:Print("Please lock your bars first")
		return
	else
		self.db.profile[arg1:GetName()].Scale = nil
		self.db.profile[arg1:GetName()].Padding = nil
		self.db.profile[arg1:GetName()].Swap = nil
		self.db.profile[arg1:GetName()].Hide = nil
		arg1:Show()
		arg1:SetScale(1)
		if ((arg1 == Bar1) or (arg1 == Bar2) or (arg1 == Bar3) or (arg1 == Bar4) or (arg1 == Bar5) or (arg1 == Bar10)) then
			self:ShowHK(arg1)
		end
		self:ResetAlpha(arg1)
		self:ResetPosition(arg1)
		self["Setup"..arg1:GetName()](self)
	end
end

function Bartender:ResetALL()
	self:Print("Creating new DB")
	self:ResetDB("profile")
	self:DefaultBars()
	self:SetupBars()
	self:ShowBorder()
	self:UPDATE_BONUS_ACTIONBAR()
	self:Lock()
end

function Bartender:LockButtons()
	if LOCK_ACTIONBAR == "1" then
		LOCK_ACTIONBAR = "0"
		Bartender:Print("ActionBar lock |cffffffcf[|r|cffff0000Off|cffffffcf]|r")
	else
		LOCK_ACTIONBAR = "1"
		Bartender:Print("ActionBar lock |cffffffcf[|r|cff00ff00On|cffffffcf]|r")
	end
end

function Bartender:Move()
	if self.binding then self:Print("Finish binding keys before moving bars.") return end
	for i=1,10 do
		_G["Bar"..i]:EnableMouse(true)
		_G["Bar"..i]:SetScript("OnEnter", function() this:SetBackdropBorderColor(0.5, 0.5, 0, 1) end)
		_G["Bar"..i]:SetScript("OnLeave", function() this:SetBackdropBorderColor(0, 0, 0, 0) end)
		_G["Bar"..i]:SetScript("OnDragStart", function() this:StartMoving() this:SetBackdropBorderColor(0, 0, 0, 0) end)
		_G["Bar"..i]:SetScript("OnDragStop", function() this:StopMovingOrSizing() self:SavePosition(this) end)
		_G["Bar"..i]:SetBackdropColor(0, 1, 0, 0.5)
		_G["Bar"..i]:SetFrameLevel(3)
	end
	for i,v in ipairs(AllButtons) do v:SetAlpha(0.5) v:SetFrameLevel(2) end
	Bar1.Text:SetText("Bar1")
	Bar2.Text:SetText("Bar2")
	Bar3.Text:SetText("Bar3")
	Bar4.Text:SetText("Bar4")
	Bar5.Text:SetText("Bar5")
	Bar6.Text:SetText("Bar6 (Shapebar)")
	Bar7.Text:SetText("Bar7 (Petbar)")
	Bar8.Text:SetText("Bar8 (Bagbar)")
	Bar9.Text:SetText("Bar9 (Microbar)")
	Bar10.Text:SetText("Bar10 (Bonusbar)")
	self.unlock = true
	self:EnableAllBars()
end

function Bartender:Lock()
	for i=1,10 do
		_G["Bar"..i]:EnableMouse(false)
		_G["Bar"..i]:SetScript("OnEnter", function() self:DummyFunction() end)
		_G["Bar"..i]:SetScript("OnLeave", function() self:DummyFunction() end)
		_G["Bar"..i]:SetScript("OnDragStart", function() self:DummyFunction() end)
		_G["Bar"..i]:SetScript("OnDragStop", function() self:DummyFunction() end)
		_G["Bar"..i]:SetBackdropColor(0, 0, 0, 0)
		_G["Bar"..i]:SetBackdropBorderColor(0, 0, 0, 0)
		_G["Bar"..i].Text:SetText("")
		_G["Bar"..i]:SetFrameLevel(1)
	end
	for i,v in ipairs(AllButtons) do v:SetFrameLevel(2) end
	self:ButtonAlphaCheck()
	self.unlock = nil
end

function Bartender:DummyFunction()
end

function Bartender:ActionButton_ShowGrid(button)
	if ( not button ) then
		button = this;
	end
	if not button then return end
	button.showgrid = (button.showgrid or 0) + 1
	local texture = _G[button:GetName().."NormalTexture"]
	if texture then
		texture:SetVertexColor(0,0,0)
		texture:SetAlpha(0.3)
	end
	button:Show()
end

function Bartender:ActionButton_HideGrid(button)
	if ( not button ) then
		button = this;
	end
	if not button then return end
	button.showgrid = math.max(0, (button.showgrid or 0) - 1)
	if ( button.showgrid == 0 and not HasAction(ActionButton_GetPagedID(button)) ) then
		button:Hide()
		self:HideNormalTexture()
	end
end

function Bartender:MultiActionBar_ShowAllGrids()
	self.hooks["MultiActionBar_ShowAllGrids"].orig()
	for i=1,12 do
		_G["Bar1Button"..i]:Show()
		_G["Bar1Button"..i.."NT"]:SetVertexColor(0,0,0)
		_G["Bar1Button"..i.."NT"]:SetAlpha(0.3)
	end
	self:HideNormalTexture()
end

function Bartender:MultiActionBar_HideAllGrids()
		self.hooks["MultiActionBar_HideAllGrids"].orig()
		for i=1,12 do
			local buttons = _G["Bar1Button"..i]
			if ( not HasAction(ActionButton_GetPagedID(buttons)) ) then
				buttons:Hide()
			end
		end
	self:HideNormalTexture()
end

function Bartender:UpdateTalentButton()
end

function Bartender:MainMenuBar_UpdateKeyRing()
	KeyRingButton:Hide()
end

function Bartender:HideNormalTexture()
	for i,v in ipairs(AllNormalTextures) do v:SetAlpha(0) end
end

function Bartender:UPDATE_BONUS_ACTIONBAR()
	if self.db.profile.Bar10.NoSwap then 
		Bar10:Hide()
		Bar1:Show()
		CURRENT_ACTIONBAR_PAGE = 1
		ChangeActionBarPage()
		BonusActionBarFrame:Hide()
		return
	else
		local x = GetBonusBarOffset()
		if x == 3 then
			Bar1:Hide()
			if not self.db.profile.Bar10.Hide then
				Bar10:Show()
				BonusActionBarFrame:Show()
			end
			CURRENT_ACTIONBAR_PAGE = 9
			ChangeActionBarPage()
		elseif x == 2 then
			Bar1:Hide()
			if not self.db.profile.Bar10.Hide then
				Bar10:Show()
				BonusActionBarFrame:Show()
			end
			CURRENT_ACTIONBAR_PAGE = 8
			ChangeActionBarPage()
		elseif x == 1 then
			Bar1:Hide()
			if not self.db.profile.Bar10.Hide then
				Bar10:Show()
				BonusActionBarFrame:Show()
			end
			CURRENT_ACTIONBAR_PAGE = 7
			ChangeActionBarPage()
		else
			Bar10:Hide()
			if not self.db.profile.Bar1.Hide then
				Bar1:Show()
				BonusActionBarFrame:Hide()
			end
			CURRENT_ACTIONBAR_PAGE = 1
			ChangeActionBarPage()
			BonusActionBarFrame:Hide()
		end
	end
end
