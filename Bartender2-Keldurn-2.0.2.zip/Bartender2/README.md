# Bartender2 for Keldurn

Move your action bars, change their layout, and bind keys by hovering over buttons.

**Version:** 2.0-Keldurn.2
**Target:** Keldurn's Windows client and its WoW 1.12 interface.

This is an adaptation of Mikma's Bartender2 2.0.11401, using the existing Blizzard buttons and bundled Ace2 libraries. The original authors' credits and source files are retained.

## Install

1. Close Keldurn.
2. Press **Win + R**, paste the path below, and press Enter:

   ```text
   %LOCALAPPDATA%\Keldurn\settings\AddOns
   ```

3. Extract the ZIP there. The folder structure must be:

   ```text
   AddOns\Bartender2\Bartender2.toc
   ```

4. If Bartender2 is already installed, replace its addon files with this version. Keep your saved settings; you do not need to reset your bars.
5. Launch Keldurn and enable **Bartender2 Keldurn** in the character screen's AddOns menu.

You can also use **Install ZIP** in that AddOns menu to select this ZIP.

## Move bars

Type `/bar lock` to unlock the bars, drag the green bar handles, then type `/bar lock` again to lock them. Positions, scales, layouts, and existing profiles are retained.

## Bind keys

1. Type `/bar bind`.
2. Hover over an action, stance, or pet button.
3. Press the desired key. **Shift**, **Ctrl**, and **Alt** combinations work; middle click, mouse buttons 4/5, and the mouse wheel are also supported.
4. Click **Save** or press **Escape** to save and exit. Clicking **Cancel** restores the bindings from before the session.

**Backspace** or **Delete** clears the hovered button's bindings. Left and right click are reserved. Bind mode reveals empty action slots, temporarily locks bar movement, and closes if combat starts. A key assigned to another action moves to the hovered button.

The bonus/form bar uses the main action bar's keys. The pet bar uses separate pet-action keys. Bag and micro-menu buttons are movable but are not included in hover binding.

## Commands

`/bartender` also works wherever `/bar` is used.

| Command | Action |
|---|---|
| `/bar lock` | Unlock or lock bar movement |
| `/bar bind` | Enter bind mode, or save and exit it |
| `/bar repair` | Reapply button layout without resetting positions |
| `/bar diag` | Print bar dimensions and binding-capture support |
| `/bar bar1 rows 1` | Make the main bar one horizontal row |
| `/bar bar1 rows 3` | Make the main bar three rows of four buttons |
| `/bar bar2 scale 1.2` | Scale bar 2 |
| `/bar bar2 padding 4` | Set bar 2's button spacing |

Action bars support 1, 2, 3, 4, 6, or 12 rows. `/bar` lists the other original options.

## Compatibility changes

- Position each button explicitly relative to its owning bar, using actual frame objects instead of Lua alias names.
- Clear previous anchors when switching layouts and orientations.
- Size and anchor the native multi-bar containers to match their custom bars; reapply geometry after native bar updates.
- Remove conflicting initial anchors from bars without custom positions.
- Restore each bar's own opacity when locking.
- Add hover binding, Save/Cancel controls, and balanced empty-slot grids.
- Preserve the native pet-bar container and refresh its buttons on login, pet summons/dismissals, action updates, and the Show toggle. Native sliding no longer hides the custom pet bar.

The addon uses vanilla-compatible Lua syntax. Offline checks passed under Lua 5.0, including simulated native layout updates, profile preservation, form/pet binding mappings, and cancellation after bindings are displaced.

**Live Keldurn verification is still needed.** If a bar is misplaced, try `/bar repair`. For a remaining problem, include a screenshot, `/bar diag` output, and your Keldurn client version.

## Source and credits

The ZIP includes editable source, original documentation, and the original bundled libraries. No standalone licence was supplied with the uploaded Bartender2 version; this adaptation does not change the original authors' licence terms.

Developers can run the offline regression checks from this folder:

```sh
lua Tests/run.lua
```

To compare against the original layout's alias-name behavior:

```sh
lua Tests/run.lua /path/to/original/Bartender2.lua
```
