-- Offline regression tests; run with Lua 5.0 from the Bartender2 folder:
-- lua Tests/run.lua [path-to-original-Bartender2.lua]
-- The fake native registry deliberately does not resolve Lua button aliases.
local globals = getfenv(0)
local registry = {}
local Frame = {}
Frame.__index = Frame
local assertions, cases = 0, 0
local function equal(actual, expected, message)
	assertions = assertions + 1
	assert(actual == expected, (message or "comparison")..": expected "..tostring(expected)..", got "..tostring(actual))
end
local function check(value, message)
	assertions = assertions + 1
	assert(value, message)
end
local function test(name, fn)
	fn()
	cases = cases + 1
	print("PASS "..name)
end
local function copy(value)
	if type(value) ~= "table" then return value end
	local out = {}
	for k,v in pairs(value) do out[k] = copy(v) end
	return out
end
local function resolve(value)
	if type(value) == "string" then
		assert(registry[value], "Native frame name is not registered: "..value)
		return registry[value]
	end
	return value
end
function CreateFrame(kind, name, parent)
	local frame = setmetatable({name = name, parent = resolve(parent), width = 36, height = 36, scale = 1, alpha = 1, level = 2, shown = true, points = {}, scripts = {}}, Frame)
	if name then registry[name] = frame globals[name] = frame end
	return frame
end
function Frame:GetName() return self.name end
function Frame:SetParent(parent) self.parent = resolve(parent) end
function Frame:GetParent() return self.parent end
function Frame:ClearAllPoints() self.points = {} end
function Frame:SetPoint(point, relative, relativePoint, x, y)
	local anchor = {point, resolve(relative), relativePoint, x or 0, y or 0}
	for i, old in ipairs(self.points) do
		if old[1] == point then self.points[i] = anchor return end
	end
	table.insert(self.points, anchor)
end
function Frame:SetAllPoints(parent)
	self:ClearAllPoints()
	self:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, 0)
	self:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", 0, 0)
end
function Frame:GetWidth() return self.width end
function Frame:GetHeight() return self.height end
function Frame:SetWidth(value) self.width = value end
function Frame:SetHeight(value) self.height = value end
function Frame:GetLeft() return self.left or self.points[1][4] end
function Frame:GetBottom() return self.bottom or self.points[1][5] end
function Frame:SetScale(value) assert(value and value > 0) self.scale = value end
function Frame:GetEffectiveScale() return self.scale * (self.parent and self.parent:GetEffectiveScale() or 1) end
function Frame:SetAlpha(value) self.alpha = value end
function Frame:SetFrameLevel(value) self.level = value end
function Frame:GetFrameLevel() return self.level end
function Frame:SetFrameStrata(value) self.strata = value end
function Frame:Show() self.shown = true end
function Frame:Hide() self.shown = false end
function Frame:IsShown() return self.shown end
function Frame:IsVisible() return self.shown and (not self.parent or self.parent:IsVisible()) end
function Frame:EnableMouse(value) self.mouse = value end
function Frame:EnableKeyboard(value) self.keyboard = value end
function Frame:EnableMouseWheel(value) self.wheel = value end
function Frame:SetMovable(value) self.movable = value end
function Frame:RegisterForDrag(value) self.drag = value end
function Frame:RegisterForClicks(value) self.clicks = value end
function Frame:StartMoving() self.moving = true end
function Frame:StopMovingOrSizing() self.moving = false end
function Frame:SetScript(eventName, fn) self.scripts[eventName] = fn end
function Frame:GetScript(eventName) return self.scripts[eventName] end
function Frame:SetTexture(value) self.texture = value end
function Frame:RegisterEvent(eventName) self.registeredEvent = eventName end
function Frame:CreateFontString() return CreateFrame("FontString", nil, self) end
function Frame:SetFontObject(value) self.font = value end
function Frame:SetText(value) self.text = value end
function Frame:SetBackdrop(value) self.backdrop = value end
function Frame:SetBackdropColor(r,g,b,a) self.background = {r,g,b,a} end
function Frame:SetBackdropBorderColor(r,g,b,a) self.border = {r,g,b,a} end
function Frame:SetVertexColor(r,g,b) self.vertex = {r,g,b} end
function Frame:SetTexCoord(a,b,c,d) self.texcoord = {a,b,c,d} end
UIParent = CreateFrame("Frame", "UIParent")
GameFontNormal = {}
StaticPopupDialogs = {}
function StaticPopup_Show() end
local roots = {"MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight", "MultiBarLeft", "MainMenuBar", "BonusActionBarFrame", "KeyRingButton", "PetActionBarFrame"}
for _, name in ipairs(roots) do CreateFrame("Frame", name, UIParent) end
local petOriginalUpdate = function() end
PetActionBarFrame:SetScript("OnUpdate", petOriginalUpdate)
for line in io.lines("Alias.lua") do
	local _, _, name = string.find(line, "=%s*(%w+)%s*$")
	if name and not globals[name] then
		local frame = CreateFrame("Button", name, UIParent)
		local _, _, id = string.find(name, "(%d+)$")
		frame.id = tonumber(id) or 1
		frame.showgrid = 0
		if string.find(name, "Micro") then frame.width, frame.height = 28, 58 end
		if string.find(name, "CharacterBag%dSlot$") then frame.width, frame.height = 35, 35 end
		if name == "MainMenuBarBackpackButton" then frame.width, frame.height = 45, 45 end
	end
end
local bonusOffset, combat = 0, false
local petExists, petHasBar, petSlots = true, true, 3
local petUpdateMisses = false
PET_ATTACK = "Attack"
PET_ATTACK_TEXTURE = "Interface\\Icons\\Ability_GhoulFrenzy"
function UnitExists(unit) return unit == "pet" and petExists end
function PetHasActionBar() return petHasBar end
function GetPetActionInfo(i)
	if not petExists or i > petSlots then return end
	if i == 1 then return "PET_ATTACK", "", "PET_ATTACK_TEXTURE", true end
	return "Pet action "..i, "", "Interface\\Icons\\PetSpell"..i, false
end
function PetActionBar_Update()
	for i=1,10 do
		local button = globals["PetActionButton"..i]
		if petUpdateMisses or not GetPetActionInfo(i) then button:Hide() else button:Show() end
	end
	PetActionBarFrame:ClearAllPoints()
	PetActionBarFrame:SetPoint("TOPLEFT", MainMenuBar, "BOTTOMLEFT", 36, 98)
end
function GetBonusBarOffset() return bonusOffset end
function ChangeActionBarPage() end
function SetActionBarToggles() end
function ActionButton_GetPagedID(button) return button.id end
function HasAction(id) return id ~= 12 end
function ActionButton_ShowGrid(button) button.showgrid = (button.showgrid or 0) + 1 button:Show() end
function ActionButton_HideGrid(button) button.showgrid = math.max(0, (button.showgrid or 0) - 1) end
function MultiActionBar_ShowAllGrids() end
function MultiActionBar_HideAllGrids() end
function UpdateTalentButton() end
function MainMenuBar_UpdateKeyRing() end
function MultiActionBar_Update()
	-- Simulate the native client restoring its default layout.
	for _, container in ipairs({MultiBarBottomLeft, MultiBarBottomRight, MultiBarRight, MultiBarLeft}) do
		container:ClearAllPoints()
		container:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -25, -40)
	end
	MultiBarBottomLeftButton2:ClearAllPoints()
	MultiBarBottomLeftButton2:SetPoint("TOPLEFT", MultiBarBottomLeftButton1, "TOPLEFT", 0, 0)
end
function AceLibrary()
	return {new = function()
		local addon = {hooks = {}, messages = {}, events = {}}
		function addon:RegisterDB() end
		function addon:SetModuleMixins() end
		function addon:RegisterDefaults(_, defaults) self.defaults = defaults self.db = {profile = copy(defaults)} end
		function addon:RegisterChatCommand(aliases, options) self.aliases = aliases self.options = options end
		function addon:ResetDB() self.db.profile = copy(self.defaults) end
		function addon:Print(message) table.insert(self.messages, message) end
		function addon:RegisterEvent(name) self.events[name] = true end
		function addon:ScheduleEvent() end
		function addon:Hook(name)
			self.hooks[name] = {orig = globals[name]}
			globals[name] = function() self[name](self) end
		end
		return addon
	end}
end
local bindings, keyOrder, sequence = {}, {}, 0
local shift, ctrl, alt = false, false, false
local capture, bindingSet, savedSet = false, 2, nil
local saveFailure, setFailure = false, false
local function keysFor(command)
	local keys = {}
	for key, action in pairs(bindings) do if action == command then table.insert(keys, key) end end
	table.sort(keys, function(a,b) return keyOrder[a] < keyOrder[b] end)
	return keys
end
function GetBindingKey(command) return unpack(keysFor(command)) end
function GetBindingAction(key) return bindings[key] or "" end
function SetBinding(key, command)
	if setFailure then error("simulated binding API error") end
	if key == "INVALID" then return false end
	if command then
		local keys = keysFor(command)
		if table.getn(keys) >= 2 and bindings[key] ~= command then bindings[keys[1]] = nil end
		bindings[key] = command sequence = sequence + 1 keyOrder[key] = sequence
	else
		bindings[key], keyOrder[key] = nil, nil
	end
	return true
end
function SaveBindings(set)
	if saveFailure then return false end
	savedSet = set
end
function GetCurrentBindingSet() return bindingSet end
function BenillaBindCapture(enabled) capture = enabled end
function UnitAffectingCombat() return combat end
function IsShiftKeyDown() return shift end
function IsControlKeyDown() return ctrl end
function IsAltKeyDown() return alt end
local function hover(bar, index, legacy)
	local command = (bar == 6 or bar == 7) and index or index
	for _, overlay in ipairs(Bartender.bindingButtons) do
		if overlay.bar == bar and overlay.label == "Bar"..bar..", button "..index then
			if legacy then this = overlay overlay.scripts.OnEnter() this = nil
			else overlay.scripts.OnEnter(overlay) end
			return overlay
		end
	end
	error("No overlay for bar "..bar.." button "..command)
end
local function sameBindings(expected)
	for key, action in pairs(expected) do equal(bindings[key], action, "restored "..key) end
	for key, action in pairs(bindings) do equal(expected[key], action, "no extra "..key) end
end
dofile("Defaults.lua")
dofile("Alias.lua")
dofile("Tables.lua")
dofile("Bartender2.lua")
dofile("KeyBindings.lua")
dofile("Options.lua")
Bartender.db.profile.Extra["Bar2DB-2"] = true
Bartender.db.profile.Bar2.PosX = 230
Bartender.db.profile.Bar2.PosY = 140
Bartender.db.profile.Bar2.Scale = 1.5

test("startup preserves an existing profile and creates one anchor per bar", function()
	Bartender:OnEnable()
	equal(Bartender.db.profile.Bar2.PosX, 230)
	equal(Bartender.db.profile.Bar2.PosY, 140)
	equal(Bar2.points[1][4], 230 / 1.5)
	for i=1,10 do equal(table.getn(globals["Bar"..i].points), 1, "root anchor count") end
	check(Bartender.options.args.bind and Bartender.options.args.repair, "commands registered")
end)

if arg and arg[1] then
	test("original alias-string layout fails against a native-only name registry", function()
		local patched = Bartender
		dofile(arg[1])
		local original = Bartender
		Bartender = patched
		local ok, message = pcall(original.SetupActionBars, original, Bar1)
		check(not ok and string.find(message, "not registered: Bar1Button"), "original failure reproduced")
		patched:RepairLayout()
	end)
end

test("all action-bar rows and spacing yield a rectangular grid of native buttons", function()
	for _, rows in ipairs({1,2,3,4,6,12}) do
		for _, pad in ipairs({-1,0,6,30}) do
			Bartender.db.profile.Bar2.Rows = rows
			Bartender.db.profile.Bar2.Padding = pad
			Bartender:SetupBar2()
			local columns = 12 / rows
			equal(Bar2:GetWidth(), columns * 36 + (columns - 1) * pad + 8)
			equal(Bar2:GetHeight(), rows * 36 + (rows - 1) * pad + 8)
			for i=1,12 do
				local button = globals["Bar2Button"..i]
				equal(table.getn(button.points), 1)
				equal(button.points[1][2], Bar2, "actual frame reference")
				equal(button:GetWidth(), 36)
				equal(button:GetHeight(), 36)
				local row = math.floor((i - 1) / columns)
				equal(button.points[1][4], 5 + (i - 1 - row * columns) * (36 + pad))
				equal(button.points[1][5], -3 - row * (36 + pad))
				equal(button:GetParent(), MultiBarBottomLeft)
			end
		end
	end
	equal(MultiBarBottomLeft:GetParent(), Bar2)
	equal(MultiBarBottomLeft.points[1][2], Bar2)
	equal(MultiBarBottomLeft:GetWidth(), Bar2:GetWidth())
end)

test("orientation changes clear anchors and account for different bag sizes", function()
	for _, barIndex in ipairs({6,7,8,9}) do
		local bar = globals["Bar"..barIndex]
		local count = barIndex == 8 and 5 or (barIndex == 9 and 8 or 10)
		for _, vertical in ipairs({true,false,true,false}) do
			Bartender.db.profile["Bar"..barIndex].Swap = vertical
			Bartender["SetupBar"..barIndex](Bartender)
			for i=1,count do
				local button = globals["Bar"..barIndex.."Button"..i]
				equal(table.getn(button.points), 1)
				equal(button.points[1][2], bar)
				check(button.points[1][4] + button:GetWidth() <= bar:GetWidth(), "width encloses button")
				check(button.points[1][5] + button:GetHeight() <= bar:GetHeight(), "height encloses button")
			end
		end
	end
	equal(Bar8:GetWidth(), 5 + 4 * 35 + 45 + 3, "bag widths")
end)

test("native reflows and repair keep an unsaved drag position", function()
	Bar2:ClearAllPoints()
	Bar2:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 430, 260)
	MultiActionBar_Update()
	equal(Bar2.points[1][4], 430)
	equal(Bar2.points[1][5], 260)
	equal(Bar2Button2.points[1][2], Bar2)
	equal(MultiBarBottomLeft.points[1][2], Bar2)
	Bartender:RepairLayout()
	equal(Bar2.points[1][4], 430)
	Bartender:SavePosition(Bar2)
	equal(Bartender.db.profile.Bar2.PosX, 645)
	equal(Bartender.db.profile.Bar2.PosY, 390)
	Bartender:Scale(Bar2, 2)
	equal(Bar2.points[1][4], 645 / 2)
	equal(Bar2.points[1][5], 390 / 2)
end)

test("lock restores each bar's alpha and drag handlers retain saved positions", function()
	Bartender.db.profile.Bar1.Alpha = 0.7
	Bartender.db.profile.Bar2.Alpha = 0.9
	Bartender.db.profile.Bar8.Alpha = 0.4
	Bartender:Move()
	this = Bar2 Bar2.scripts.OnDragStart() this = nil
	check(Bar2.moving, "moving began")
	this = Bar2 Bar2.scripts.OnDragStop() this = nil
	check(not Bar2.moving, "moving stopped")
	Bartender:Lock()
	equal(Bar1Button1.alpha, 0.7)
	equal(Bar2Button1.alpha, 0.9)
	equal(Bar8Button1.alpha, 0.4)
	check(not Bar2.mouse, "locked roots ignore mouse")
end)

test("bonus forms use the main binding commands and pet actions use pet commands", function()
	bonusOffset = 1
	Bartender:UPDATE_BONUS_ACTIONBAR()
	check(not Bar1:IsShown() and Bar10:IsShown(), "form bar visibility")
	equal(CURRENT_ACTIONBAR_PAGE, 7)
	Bartender:StartBinding()
	equal(hover(10, 1).command, "ACTIONBUTTON1")
	equal(hover(7, 1).command, "BONUSACTIONBUTTON1")
	equal(hover(6, 1).command, "SHAPESHIFTBUTTON1")
	Bartender:FinishBinding(false)
	bonusOffset = 0
	Bartender:UPDATE_BONUS_ACTIONBAR()
end)

test("cancel restores displaced bindings and leaves unrelated keys alone", function()
	SetBinding("1", "ACTIONBUTTON1")
	SetBinding("2", "ACTIONBUTTON1")
	SetBinding("F", "JUMP")
	SetBinding("Z", "OPENALLBAGS")
	local before = copy(bindings)
	Bartender:StartBinding()
	check(capture and Bartender.bindingFrame.keyboard, "input captured")
	hover(1, 1, true)
	Bartender:BindingKey("F")
	equal(bindings.F, "ACTIONBUTTON1")
	check(not bindings["1"], "simulated two-key limit displaced first binding")
	Bartender:FinishBinding(false)
	sameBindings(before)
	check(not capture and not Bartender.bindingFrame.keyboard, "input released")
end)

test("keyboard modifiers, middle click, and wheel save to the current binding set", function()
	Bartender:StartBinding()
	local overlay = hover(2, 3)
	ctrl, shift, alt = true, true, true
	Bartender:BindingKey("F3")
	equal(bindings["CTRL-ALT-SHIFT-F3"], "MULTIACTIONBAR1BUTTON3")
	ctrl, shift, alt = false, false, false
	overlay.scripts.OnClick(overlay, "MiddleButton")
	equal(bindings.BUTTON3, "MULTIACTIONBAR1BUTTON3")
	this, arg1 = overlay, 1 overlay.scripts.OnMouseWheel() this, arg1 = nil, nil
	equal(bindings.MOUSEWHEELUP, "MULTIACTIONBAR1BUTTON3")
	local before = copy(bindings)
	overlay.scripts.OnClick(overlay, "LeftButton")
	sameBindings(before)
	Bartender.bindingFrame.scripts.OnKeyDown(Bartender.bindingFrame, "ESCAPE")
	equal(savedSet, 2)
	check(not Bartender.binding and not capture, "save ends capture")
end)

test("delete clears all keys on the hovered action and cancel restores them", function()
	local before = copy(bindings)
	Bartender:StartBinding()
	hover(2, 3)
	Bartender:BindingKey("DELETE")
	equal(table.getn(keysFor("MULTIACTIONBAR1BUTTON3")), 0)
	Bartender:FinishBinding(false)
	sameBindings(before)
end)

test("hidden bars cannot be bound and modifier-only presses do nothing", function()
	Bartender:StartBinding()
	Bar4:Hide()
	hover(4, 1)
	Bartender:BindingKey("F8")
	check(not bindings.F8, "hidden target ignored")
	Bar4:Show()
	hover(4, 1)
	Bartender:BindingKey("LSHIFT")
	check(not bindings.LSHIFT, "modifier-only key ignored")
	Bartender:FinishBinding(false)
end)

test("failed key assignments and saves report errors without claiming success", function()
	Bartender:StartBinding()
	hover(1, 3)
	Bartender:BindingKey("INVALID")
	check(string.find(Bartender.bindingFrame.status.text, "could not bind"), "failed set feedback")
	saveFailure = true
	Bartender:FinishBinding(true)
	check(Bartender.binding and capture, "save can be retried or cancelled")
	saveFailure = false
	Bartender:FinishBinding(false)
	check(not Bartender.binding and not capture, "cancel still works")
end)

test("empty-slot grids balance counters and return empty buttons to hidden", function()
	Bar1Button12.showgrid = nil
	Bartender:StartBinding()
	equal(Bar1Button12.showgrid, 1)
	check(Bar1Button12:IsShown(), "empty slot revealed")
	Bartender:FinishBinding(false)
	equal(Bar1Button12.showgrid, 0)
	check(not Bar1Button12:IsShown(), "empty slot hidden again")
	check(not Bartender.bindingButtons[1]:IsShown(), "overlay hidden")
end)

test("combat blocks entry and restores bindings when combat starts", function()
	combat = true
	Bartender:StartBinding()
	check(not Bartender.binding and not capture, "entry blocked in combat")
	combat = false
	local before = copy(bindings)
	Bartender:StartBinding()
	hover(3, 4)
	Bartender:BindingKey("G")
	this, event = Bartender.bindingFrame, "PLAYER_REGEN_DISABLED"
	Bartender.bindingFrame.scripts.OnEvent()
	this, event = nil, nil
	sameBindings(before)
	check(not capture and not Bartender.binding, "combat cancellation releases input")
end)

test("binding restores the previous unlocked state", function()
	Bartender:Move()
	Bartender:StartBinding()
	check(not Bartender.unlock, "locked during capture")
	Bartender:Move()
	check(not Bartender.unlock, "cannot move while binding")
	Bartender:FinishBinding(false)
	check(Bartender.unlock and Bar2.mouse, "unlock restored")
	Bartender:Lock()
end)

test("capture API failure aborts entry without changing the layout lock", function()
	local native = BenillaBindCapture
	BenillaBindCapture = function() error("unsupported signature") end
	Bartender:StartBinding()
	check(not Bartender.binding and not capture, "entry aborted")
	BenillaBindCapture = native
end)

test("rollback errors still release input and explain the failure", function()
	Bartender:StartBinding()
	hover(1, 5)
	Bartender:BindingKey("F9")
	setFailure = true
	Bartender:FinishBinding(false)
	setFailure = false
	check(not Bartender.binding and not capture, "failed rollback releases capture")
	check(string.find(Bartender.messages[table.getn(Bartender.messages)], "could not be restored"), "rollback warning")
	SetBinding("F9")
end)

test("profile changes and addon disable cancel pending bindings", function()
	local before = copy(bindings)
	Bartender:StartBinding()
	hover(1, 6)
	Bartender:BindingKey("F10")
	Bartender:OnProfileEnable()
	sameBindings(before)
	check(not capture, "profile change releases capture")
	Bartender:StartBinding()
	hover(1, 6)
	Bartender:BindingKey("F10")
	Bartender:OnDisable()
	sameBindings(before)
	check(not capture, "disable releases capture")
end)

test("diagnostics work with fallback defaults and repair preserves hidden bars", function()
	Bartender.db.profile.Bar2.Padding = nil
	Bartender:LayoutDiagnostics()
	Bartender.db.profile.Bar3.Hide = true
	Bartender:RepairLayout()
	check(not Bar3:IsShown(), "hidden bar stays hidden")
end)

test("hunter pet buttons and icons refresh even when the native updater leaves them hidden", function()
	petExists, petHasBar, petSlots, petUpdateMisses = true, false, 3, true
	Bartender.db.profile.Bar7.Hide = nil
	Bartender:SetAllParents()
	PetActionBarFrame:Hide()
	for i=1,10 do globals["PetActionButton"..i]:Hide() end
	Bartender:RefreshPetBar()
	check(not MainMenuBar:IsShown(), "main menu stays hidden")
	equal(PetActionBarFrame:GetParent(), Bar7, "native pet container preserved")
	equal(PetActionButton1:GetParent(), PetActionBarFrame, "pet button parent")
	check(PetActionButton1:IsVisible(), "populated pet action visible")
	check(PetActionButton1Icon:IsVisible(), "pet icon visible")
	equal(PetActionButton1Icon.texture, PET_ATTACK_TEXTURE, "token texture resolved")
	equal(PetActionButton1.tooltipName, "Attack", "token tooltip resolved")
	check(not PetActionButton4:IsShown(), "empty pet slot hidden")
	equal(PetActionBarFrame.points[1][2], Bar7, "native sliding position cleared")
	check(not PetActionBarFrame:GetScript("OnUpdate"), "native sliding disabled")
	petHasBar, petUpdateMisses = true, false
end)

test("pet summon, dismiss, action updates, and show toggles preserve layout and visibility", function()
	local x, y = Bar7.points[1][4], Bar7.points[1][5]
	petExists, petHasBar = false, false
	Bartender.events = Bartender.events or {}
	check(Bartender.events.UNIT_PET and Bartender.events.PET_BAR_UPDATE, "pet events registered")
	Bartender:RefreshPetBar()
	check(not PetActionButton1:IsVisible(), "dismissal hides actions")
	petExists, petHasBar = true, true
	Bartender:RefreshPetBar()
	check(PetActionButton1:IsVisible(), "summon restores actions")
	Bartender:HideBar(Bar7)
	PetActionBar_Update()
	check(not PetActionButton1:IsVisible(), "native refresh respects hidden profile")
	Bartender:ShowBar(Bar7)
	check(PetActionButton1:IsVisible(), "show toggle restores populated buttons")
	equal(Bar7.points[1][4], x, "saved horizontal position untouched")
	equal(Bar7.points[1][5], y, "saved vertical position untouched")
	Bartender:OnDisable()
	equal(PetActionBarFrame:GetScript("OnUpdate"), petOriginalUpdate, "original update restored on disable")
	Bartender:SetAllParents()
end)

test("pet visibility has a fallback when the native frame or updater is missing", function()
	local frame, updater = PetActionBarFrame, PetActionBar_Update
	PetActionBarFrame, PetActionBar_Update = nil, nil
	Bartender:SetAllParents()
	Bartender:RefreshPetBar()
	equal(PetActionButton1:GetParent(), Bar7)
	check(PetActionButton1:IsVisible(), "fallback pet controls visible")
	PetActionBarFrame, PetActionBar_Update = frame, updater
	Bartender:SetAllParents()
	Bartender:RefreshPetBar()
	local texture = PET_ATTACK_TEXTURE
	PET_ATTACK_TEXTURE = nil
	Bartender:RefreshPetBar()
	equal(PetActionButton1Icon.texture, texture, "pet token icon fallback")
	PET_ATTACK_TEXTURE = texture
end)

test("a native pet update error does not prevent basic controls from appearing", function()
	local native = Bartender.hooks.PetActionBar_Update.orig
	Bartender.hooks.PetActionBar_Update.orig = function() error("missing native UI element") end
	PetActionButton1:Hide()
	Bartender:RefreshPetBar()
	check(PetActionButton1:IsVisible(), "pet controls survive native update failure")
	check(Bartender.petUpdateErrorReported, "native error surfaced")
	Bartender.hooks.PetActionBar_Update.orig = native
end)

print("Passed "..cases.." regression scenarios; "..assertions.." assertions (simulated client).")
