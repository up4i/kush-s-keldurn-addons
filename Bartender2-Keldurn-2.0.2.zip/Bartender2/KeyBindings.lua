-- Hover binding for the original 1.12 buttons, without secure templates.
local globals = getfenv(0)
local commands = {
	[1] = "ACTIONBUTTON", [2] = "MULTIACTIONBAR1BUTTON",
	[3] = "MULTIACTIONBAR2BUTTON", [4] = "MULTIACTIONBAR3BUTTON",
	[5] = "MULTIACTIONBAR4BUTTON", [6] = "SHAPESHIFTBUTTON",
	[7] = "BONUSACTIONBUTTON", [10] = "ACTIONBUTTON",
}
local mouseKeys = {
	LeftButton = "BUTTON1", RightButton = "BUTTON2", MiddleButton = "BUTTON3",
	Button4 = "BUTTON4", Button5 = "BUTTON5",
}
local modifiers = {
	SHIFT = true, LSHIFT = true, RSHIFT = true,
	CTRL = true, LCTRL = true, RCTRL = true,
	CONTROL = true, LCONTROL = true, RCONTROL = true,
	ALT = true, LALT = true, RALT = true,
}

local function bindingButton(parent, name, label, x)
	-- Keldurn's XML templates do not always create a button's NormalText.
	local button = CreateFrame("Button", name, parent)
	button:SetWidth(100) button:SetHeight(24)
	button:SetPoint("BOTTOM", parent, "BOTTOM", x, 11)
	button:EnableMouse(true)
	button:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 8})
	button:SetBackdropColor(0.12, 0.2, 0.16, 1)
	local text = button:CreateFontString(nil, "OVERLAY")
	text:SetFontObject(GameFontNormal)
	text:SetPoint("CENTER", button, "CENTER", 0, 0)
	text:SetText(label)
	return button
end

function Bartender:CreateBindingUI()
	if self.bindingFrame then return end
	local frame = CreateFrame("Frame", "Bartender2BindingFrame", UIParent)
	frame:SetWidth(550)
	frame:SetHeight(130)
	frame:SetPoint("TOP", UIParent, "TOP", 0, -75)
	frame:SetFrameStrata("DIALOG")
	frame:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, insets = {left = 4, right = 4, top = 4, bottom = 4}})
	frame:SetBackdropColor(0.04, 0.04, 0.04, 0.95)
	frame:SetBackdropBorderColor(0.3, 0.8, 0.5, 1)
	frame.text = frame:CreateFontString(nil, "OVERLAY")
	frame.text:SetFontObject(GameFontNormal)
	frame.text:SetWidth(520)
	frame.text:SetPoint("TOP", frame, "TOP", 0, -12)
	frame.text:SetText("Bartender2: bind mode\nHover a button and press a key or scroll the wheel.\nShift / Ctrl / Alt work. Backspace or Delete clears that button.\nEscape saves and exits; Cancel restores your previous bindings.")
	frame.status = frame:CreateFontString(nil, "OVERLAY")
	frame.status:SetFontObject(GameFontNormal)
	frame.status:SetWidth(520)
	frame.status:SetPoint("BOTTOM", frame, "BOTTOM", 0, 41)
	local save = bindingButton(frame, "Bartender2BindingSave", "Save", -60)
	save:SetScript("OnClick", function() Bartender:FinishBinding(true) end)
	local cancel = bindingButton(frame, "Bartender2BindingCancel", "Cancel", 60)
	cancel:SetScript("OnClick", function() Bartender:FinishBinding(false) end)
	frame:SetScript("OnKeyDown", function(_, key) Bartender:BindingKey(key or arg1) end)
	frame:RegisterEvent("PLAYER_REGEN_DISABLED")
	frame:SetScript("OnEvent", function(_, eventName)
		if (eventName or event) == "PLAYER_REGEN_DISABLED" and Bartender.binding then
			Bartender:FinishBinding(false)
			Bartender:Print("Bind mode cancelled because combat started.")
		end
	end)
	frame:EnableKeyboard(false)
	frame:Hide()
	self.bindingFrame = frame
	self.bindingButtons = {}
	for bar=1,10 do
		if commands[bar] then
			local count = (bar == 6 or bar == 7) and 10 or 12
			for i=1,count do
				local button = globals["Bar"..bar.."Button"..i]
				if button then
					local overlay = CreateFrame("Button", nil, button)
					overlay:SetAllPoints(button)
					overlay:SetFrameLevel(button:GetFrameLevel() + 10)
					overlay:EnableMouse(true)
					overlay:EnableMouseWheel(true)
					overlay:RegisterForClicks("AnyUp")
					overlay:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 8})
					overlay:SetBackdropColor(0, 0.5, 0.2, 0.15)
					overlay:SetBackdropBorderColor(0.2, 0.8, 0.4, 0.7)
					overlay.button = button
					overlay.bar = bar
					overlay.command = commands[bar]..i
					overlay.label = "Bar"..bar..", button "..i
					overlay.hotkey = globals["Bar"..bar.."Button"..i.."HK"]
					overlay:SetScript("OnEnter", function(target)
						target = target or this
						Bartender.bindingHover = target
						target:SetBackdropBorderColor(1, 0.85, 0.2, 1)
						Bartender:UpdateBindingStatus()
					end)
					overlay:SetScript("OnLeave", function(target)
						target = target or this
						if Bartender.bindingHover == target then Bartender.bindingHover = nil end
						target:SetBackdropBorderColor(0.2, 0.8, 0.4, 0.7)
						Bartender:UpdateBindingStatus()
					end)
					overlay:SetScript("OnClick", function(target, mouseButton)
						target = target or this
						Bartender.bindingHover = target
						Bartender:AssignBinding(mouseKeys[mouseButton or arg1])
					end)
					overlay:SetScript("OnMouseWheel", function(target, delta)
						target = target or this
						Bartender.bindingHover = target
						delta = delta or arg1 or 0
						if delta ~= 0 then Bartender:AssignBinding(delta > 0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN") end
					end)
					overlay:Hide()
					table.insert(self.bindingButtons, overlay)
				end
			end
		end
	end
end

function Bartender:UpdateBindingStatus(message)
	if not self.binding then return end
	local target = self.bindingHover
	if message then
		self.bindingFrame.status:SetText(message)
	elseif target then
		local keys = { GetBindingKey(target.command) }
		local text = table.concat(keys, ", ")
		if text == "" then text = "unbound" end
		self.bindingFrame.status:SetText(target.label..": "..text)
	else
		self.bindingFrame.status:SetText("Hover an action, stance, or pet button.")
	end
end

function Bartender:RememberBinding(key)
	if self.bindingOriginal[key] == nil then
		self.bindingOriginal[key] = GetBindingAction(key) or ""
	end
end

function Bartender:RememberCommandBindings(command)
	-- Also remember the target's keys: some clients limit keys per command.
	for _, key in ipairs({ GetBindingKey(command) }) do self:RememberBinding(key) end
end

function Bartender:AssignBinding(key)
	local target = self.bindingHover
	if not self.binding or not target or not key or modifiers[key] then return end
	if not target.button:IsVisible() then self.bindingHover = nil return end
	if key == "BUTTON1" or key == "BUTTON2" then
		self:UpdateBindingStatus("Left and right click are reserved; use a key, middle click, or the wheel.")
		return
	end
	if IsShiftKeyDown() then key = "SHIFT-"..key end
	if IsAltKeyDown() then key = "ALT-"..key end
	if IsControlKeyDown() then key = "CTRL-"..key end
	self:RememberBinding(key)
	self:RememberCommandBindings(target.command)
	local ok, result = pcall(SetBinding, key, target.command)
	if not ok or not result then
		self:UpdateBindingStatus("The client could not bind "..key..". Try another key.")
		return
	end
	self:RefreshBindingLabels()
	self:UpdateBindingStatus()
end

function Bartender:BindingKey(key)
	if not self.binding or not key then return end
	if key == "ESCAPE" then self:FinishBinding(true) return end
	if key == "BACKSPACE" or key == "DELETE" then
		local target = self.bindingHover
		if not target or not target.button:IsVisible() then return end
		for _, bindingKey in ipairs({ GetBindingKey(target.command) }) do
			self:RememberBinding(bindingKey)
			local ok, result = pcall(SetBinding, bindingKey)
			if not ok or not result then
				self:UpdateBindingStatus("The client could not clear this binding.")
				return
			end
		end
		self:RefreshBindingLabels()
		self:UpdateBindingStatus()
		return
	end
	self:AssignBinding(key)
end

function Bartender:RefreshBindingLabels()
	for _, overlay in ipairs(self.bindingButtons) do
		if overlay.hotkey then
			local key = GetBindingKey(overlay.command)
			overlay.hotkey:SetText(key or "")
			if self.db.profile["Bar"..overlay.bar].HideHotKey then overlay.hotkey:Hide() end
		end
	end
end

function Bartender:StartBinding()
	if self.binding then return end
	if UnitAffectingCombat("player") then self:Print("Leave combat before binding keys.") return end
	if type(SetBinding) ~= "function" or type(GetBindingKey) ~= "function" or type(GetBindingAction) ~= "function" or type(SaveBindings) ~= "function" then
		self:Print("This client is missing the keybinding API.") return
	end
	self:CreateBindingUI()
	if type(BenillaBindCapture) == "function" then
		local ok = pcall(BenillaBindCapture, true)
		if not ok then self:Print("The client could not start key capture.") return end
	end
	self.bindingWasUnlocked = self.unlock
	self:Lock()
	self.binding = true
	self.bindingOriginal = {}
	self.bindingHover = nil
	for _, overlay in ipairs(self.bindingButtons) do
		if overlay.bar ~= 6 and overlay.bar ~= 7 then
			self:ActionButton_ShowGrid(overlay.button)
			overlay.gridShown = true
		end
		overlay:SetFrameLevel(overlay.button:GetFrameLevel() + 10)
		overlay:Show()
	end
	self.bindingFrame:Show()
	self.bindingFrame:EnableKeyboard(true)
	self:UpdateBindingStatus()
	self:Print("Bind mode: hover a button and press its key. Escape saves; Cancel restores.")
end

function Bartender:FinishBinding(save)
	if not self.binding then return end
	local restored = true
	if save then
		local set = type(GetCurrentBindingSet) == "function" and GetCurrentBindingSet() or 1
		if set ~= 1 and set ~= 2 then set = 1 end
		local ok, result = pcall(SaveBindings, set)
		if not ok or result == false then
			self:UpdateBindingStatus("The client could not save. Try Save again, or Cancel.")
			return
		end
	else
		-- Clear changed keys first so restoring one cannot displace another.
		for key in pairs(self.bindingOriginal) do
			local ok, result = pcall(SetBinding, key)
			if not ok or not result then restored = false end
		end
		for key, command in pairs(self.bindingOriginal) do
			if command ~= "" then
				local ok, result = pcall(SetBinding, key, command)
				if not ok or not result then restored = false end
			end
		end
	end
	self.binding = nil
	self.bindingHover = nil
	self.bindingOriginal = nil
	self.bindingFrame:EnableKeyboard(false)
	self.bindingFrame:Hide()
	if type(BenillaBindCapture) == "function" then pcall(BenillaBindCapture, false) end
	for _, overlay in ipairs(self.bindingButtons) do
		overlay:Hide()
		if overlay.gridShown then self:ActionButton_HideGrid(overlay.button) overlay.gridShown = nil end
	end
	self:HideNormalTexture()
	self:RefreshBindingLabels()
	if self.bindingWasUnlocked then self:Move() end
	self.bindingWasUnlocked = nil
	if not restored then
		self:Print("Bind mode closed. Some bindings could not be restored; check the game's Key Bindings menu.")
	else
		self:Print(save and "Keybindings saved." or "Binding changes cancelled.")
	end
end

function Bartender:ToggleBinding()
	if self.binding then self:FinishBinding(true) else self:StartBinding() end
end

function Bartender:LayoutDiagnostics()
	self:Print("Keldurn layout "..self.version.."; bind capture: "..(type(BenillaBindCapture) == "function" and "available" or "standard keyboard"))
	for i=1,10 do
		local bar = globals["Bar"..i]
		local profile = self.db.profile["Bar"..i]
		self:Print("Bar"..i..": "..bar:GetWidth().." x "..bar:GetHeight()..", scale "..(profile.Scale or 1)..", padding "..(profile.Padding or BT2Defaults["Bar"..i].Padding))
	end
	local populated, visible = 0, 0
	if type(GetPetActionInfo) == "function" then
		for i=1,10 do
			if GetPetActionInfo(i) then populated = populated + 1 end
			if globals["Bar7Button"..i]:IsVisible() then visible = visible + 1 end
		end
	end
	self:Print("Pet: exists "..tostring(UnitExists("pet"))..", populated slots "..populated..", visible buttons "..visible)
end
