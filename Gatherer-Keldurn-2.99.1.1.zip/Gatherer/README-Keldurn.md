# Gatherer for Keldurn

Compatibility patch for Gatherer 2.99.1. Removes the duplicated semicolon in the Hide Icon checkbox click handler that prevents it from compiling. All other original files and saved-variable names are unchanged.

Close Keldurn and extract the Gatherer folder into `%LOCALAPPDATA%\Keldurn\settings\AddOns`, replacing the existing Gatherer folder. Restart and enable Gatherer at character selection. Keep your saved variables to preserve recorded nodes and settings.

Validation: all Lua files and 279 XML handlers compile with Lua 5.0. Both Hide Icon checkbox states pass a simulated execution check. In-game validation remains necessary.
