-- Run from KeldurnMeter/: lua tests/test.lua (Lua 5.0 or 5.1).
-- No addon libraries, test framework, or game installation is required.
local passed = 0
local function eq(actual, expected, label)
  if actual ~= expected then
    error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
  end
  passed = passed + 1
end
local function near(actual, expected, label)
  if math.abs(actual - expected) > 0.00001 then error(label .. ": " .. actual .. " ~= " .. expected) end
  passed = passed + 1
end

local now, locale, partyCount, raidCount = 0, "enUS", 1, 0
local names = { player = "Bryce", party1 = "Alice", pet = "Wolf", partypet1 = "Imp" }
local classes = { player = "HUNTER", party1 = "WARLOCK" }
local combat = {}
function GetTime() return now end
function GetLocale() return locale end
function getglobal(name) return _G[name] end
function UnitName(unit) return names[unit] end
function UnitClass(unit) return classes[unit], classes[unit] end
function UnitAffectingCombat(unit) return combat[unit] end
function GetNumPartyMembers() return partyCount end
function GetNumRaidMembers() return raidCount end
SlashCmdList = {}
UNKNOWN = "Unknown"
local messages = {}
DEFAULT_CHAT_FRAME = { AddMessage = function(self, message) table.insert(messages, message) end }

-- Strict UI stand-in: undefined methods fail instead of silently succeeding.
local methods = {}
local function frame(kind, name, parent)
  local object = { kind = kind, parent = parent, scripts = {}, shown = true, events = {} }
  setmetatable(object, { __index = methods })
  object.children = {}
  if parent then table.insert(parent.children, object) end
  if name then _G[name] = object end
  return object
end
function CreateFrame(kind, name, parent) return frame(kind, name, parent) end
function methods:CreateFontString() return frame("FontString", nil, self) end
function methods:CreateTexture() return frame("Texture", nil, self) end
function methods:SetTexture(path) self.texture = path end
function methods:SetWidth(value)
  if self.minWidth then value = math.max(self.minWidth, math.min(self.maxWidth, value)) end
  self.width = value
  if self.scripts.OnSizeChanged then self.scripts.OnSizeChanged(self, value, self.height) end
end
function methods:SetHeight(value)
  if self.minHeight then value = math.max(self.minHeight, math.min(self.maxHeight, value)) end
  self.height = value
  if self.scripts.OnSizeChanged then self.scripts.OnSizeChanged(self, self.width, value) end
end
function methods:GetWidth() return self.width or (self.relative and self.relative:GetWidth()) or 0 end
function methods:GetHeight() return self.height or (self.relative and self.relative:GetHeight()) or 0 end
function methods:SetPoint(point, relative, relativePoint, x, y)
  self.point, self.anchor, self.relativePoint = point, relative, relativePoint
  self.x, self.y = x or 0, y or 0
end
function methods:ClearAllPoints() self.x, self.y = nil, nil end
function methods:SetAllPoints(relative) self.relative = relative end
local function offset(point, width, height)
  local x, y = 0, 0
  if string.find(point, "LEFT") then x = -width / 2 elseif string.find(point, "RIGHT") then x = width / 2 end
  if string.find(point, "TOP") then y = height / 2 elseif string.find(point, "BOTTOM") then y = -height / 2 end
  return x, y
end
function methods:GetCenter()
  if self == UIParent then return 960, 540 end
  if self.relative then return self.relative:GetCenter() end
  local anchor = self.anchor or self.parent or UIParent
  local x, y = anchor:GetCenter()
  local dx, dy = offset(self.relativePoint or "CENTER", anchor:GetWidth(), anchor:GetHeight())
  local ownX, ownY = offset(self.point or "CENTER", self:GetWidth(), self:GetHeight())
  return x + dx + (self.x or 0) - ownX, y + dy + (self.y or 0) - ownY
end
function methods:GetLeft() local x = self:GetCenter(); return x - self:GetWidth() / 2 end
function methods:GetRight() local x = self:GetCenter(); return x + self:GetWidth() / 2 end
function methods:GetTop() local _, y = self:GetCenter(); return y + self:GetHeight() / 2 end
function methods:SetFont(path, size) self.font, self.fontSize = path, size end
function methods:SetJustifyH(value) self.justify = value end
function methods:SetText(value)
  assert(type(value) == "string" or type(value) == "number", "invalid label value")
  self.text = tostring(value)
end
function methods:SetTextColor() end
function methods:SetFrameStrata() end
function methods:SetBackdrop() end
function methods:SetBackdropColor() end
function methods:SetBackdropBorderColor() end
function methods:SetMovable(value) self.movable = value end
function methods:SetResizable(value) self.resizable = value end
function methods:SetMinResize(width, height) self.minWidth, self.minHeight = width, height end
function methods:SetMaxResize(width, height) self.maxWidth, self.maxHeight = width, height end
function methods:EnableMouse(value) self.mouse = value end
function methods:SetClampedToScreen(value) self.clamped = value end
function methods:RegisterForDrag() end
function methods:StartMoving() self.moving = true end
function methods:StartSizing(corner) assert(self.resizable); self.sizing = corner end
function methods:StopMovingOrSizing() self.moving, self.sizing = false, nil end
function methods:SetStatusBarTexture(value) self.texture = value end
function methods:SetMinMaxValues(minimum, maximum) self.minimum, self.maximum = minimum, maximum end
function methods:SetStatusBarColor() end
function methods:SetValue(value) self.value = value end
function methods:SetScript(name, callback) self.scripts[name] = callback end
function methods:RegisterEvent(name) self.events[name] = true end
function methods:Show() self.shown = true end
function methods:Hide() self.shown = false end
function methods:IsShown() return self.shown end
UIParent = frame("Frame", "UIParent")
UIParent.width, UIParent.height = 1920, 1080

dofile("Parser.lua")
dofile("Core.lua")
dofile("UI.lua")
local KM = KeldurnMeter
KM.controller.scripts.OnEvent(KM.controller, "ADDON_LOADED", "AnotherAddon")
eq(KM.initialized, nil, "wait for our saved variables")
KeldurnMeterDB = { metric = "dps", x = 50, y = -20 }
KM.controller.scripts.OnEvent(KM.controller, "ADDON_LOADED", "KeldurnMeter")
eq(KM.initialized, true, "initialize")
eq(KM.db.metric, "dps", "keep saved metric")
eq(KM.window.x, 50, "keep saved position")
eq(KM.window.title.text, "Damage!", "renamed window")
eq(KM.window.menu:IsShown(), false, "menu starts closed")
eq(KM.window.menuToggle.point, "TOPRIGHT", "hamburger stays top right")
eq(KM.window.resize.point, "BOTTOMRIGHT", "resize handle stays bottom right")
eq(KM.visibleRows, 10, "default number of visible rows")
eq(KM.formatCount, 35, "supported formats")
eq(table.getn(KM.registrationFailures), 0, "registered events")

-- Independent examples from vanilla's combat message grammar.
-- event family, message, source, target, ability, amount, critical
local fixtures = {
  { "melee", "You hit Boar for 12.", "Bryce", "Boar", "Melee", 12, false },
  { "melee", "You crit Boar for 24.", "Bryce", "Boar", "Melee", 24, true },
  { "melee", "You hit Boar for 13 Fire damage.", "Bryce", "Boar", "Melee", 13, false },
  { "melee", "You crit Boar for 26 Fire damage.", "Bryce", "Boar", "Melee", 26, true },
  { "melee", "Boar hits you for 7.", "Boar", "Bryce", "Melee", 7, false },
  { "melee", "Boar crits you for 14.", "Boar", "Bryce", "Melee", 14, true },
  { "melee", "Boar hits you for 8 Fire damage.", "Boar", "Bryce", "Melee", 8, false },
  { "melee", "Boar crits you for 16 Fire damage.", "Boar", "Bryce", "Melee", 16, true },
  { "melee", "Alice hits Boar for 17.", "Alice", "Boar", "Melee", 17, false },
  { "melee", "Alice crits Boar for 34.", "Alice", "Boar", "Melee", 34, true },
  { "melee", "Alice hits Boar for 18 Fire damage.", "Alice", "Boar", "Melee", 18, false },
  { "melee", "Alice crits Boar for 36 Fire damage.", "Alice", "Boar", "Melee", 36, true },
  { "spell", "Your Fireball hits you for 3.", "Bryce", "Bryce", "Fireball", 3, false },
  { "spell", "Your Fireball crits you for 6.", "Bryce", "Bryce", "Fireball", 6, true },
  { "spell", "Your Fireball hits you for 4 Fire damage.", "Bryce", "Bryce", "Fireball", 4, false },
  { "spell", "Your Fireball crits you for 8 Fire damage.", "Bryce", "Bryce", "Fireball", 8, true },
  { "spell", "Your Auto Shot hits Boar for 20.", "Bryce", "Boar", "Auto Shot", 20, false },
  { "spell", "Your Auto Shot crits Boar for 40.", "Bryce", "Boar", "Auto Shot", 40, true },
  { "spell", "Your Arcane Shot hits Boar for 21 Arcane damage.", "Bryce", "Boar", "Arcane Shot", 21, false },
  { "spell", "Your Arcane Shot crits Boar for 42 Arcane damage.", "Bryce", "Boar", "Arcane Shot", 42, true },
  { "spell", "Boar's Bite hits you for 9.", "Boar", "Bryce", "Bite", 9, false },
  { "spell", "Boar's Bite crits you for 18.", "Boar", "Bryce", "Bite", 18, true },
  { "spell", "Boar's Bite hits you for 10 Fire damage.", "Boar", "Bryce", "Bite", 10, false },
  { "spell", "Boar's Bite crits you for 20 Fire damage.", "Boar", "Bryce", "Bite", 20, true },
  { "spell", "Alice's Shadow Bolt hits Boar for 22.", "Alice", "Boar", "Shadow Bolt", 22, false },
  { "spell", "Alice's Shadow Bolt crits Boar for 44.", "Alice", "Boar", "Shadow Bolt", 44, true },
  { "spell", "Alice's Shadow Bolt hits Boar for 23 Shadow damage.", "Alice", "Boar", "Shadow Bolt", 23, false },
  { "spell", "Alice's Shadow Bolt crits Boar for 46 Shadow damage.", "Alice", "Boar", "Shadow Bolt", 46, true },
  { "periodic", "Boar suffers 11 Nature damage from your Serpent Sting.", "Bryce", "Boar", "Serpent Sting", 11, false },
  { "periodic", "Boar suffers 12 Shadow damage from Alice's Corruption.", "Alice", "Boar", "Corruption", 12, false },
  { "periodic", "You suffer 13 Fire damage from your Fireball.", "Bryce", "Bryce", "Fireball", 13, false },
  { "periodic", "You suffer 14 Shadow damage from Alice's Corruption.", "Alice", "Bryce", "Corruption", 14, false },
  { "shield", "You reflect 15 Holy damage to Boar.", "Bryce", "Boar", "Damage shield (Holy)", 15, false },
  { "shield", "Boar reflects 16 Fire damage to you.", "Boar", "Bryce", "Damage shield (Fire)", 16, false },
  { "shield", "Alice reflects 17 Fire damage to Boar.", "Alice", "Boar", "Damage shield (Fire)", 17, false }
}
local familyEvents = {
  melee = "CHAT_MSG_COMBAT_PARTY_HITS", spell = "CHAT_MSG_SPELL_PARTY_DAMAGE",
  periodic = "CHAT_MSG_SPELL_PERIODIC_PARTY_DAMAGE", shield = "CHAT_MSG_SPELL_DAMAGESHIELDS_ON_OTHERS"
}
for index, fixture in ipairs(fixtures) do
  local record = KM:Parse(familyEvents[fixture[1]], fixture[2])
  assert(record, "fixture " .. index .. " not parsed")
  eq(record.source, fixture[3], "source " .. index)
  eq(record.target, fixture[4], "target " .. index)
  eq(record.spell, fixture[5], "ability " .. index)
  eq(record.amount, fixture[6], "amount " .. index)
  eq(record.critical, fixture[7], "critical " .. index)
end
eq(KM:Parse("CHAT_MSG_COMBAT_SELF_HITS", "You miss Boar."), nil, "miss is not damage")
eq(KM:Parse("CHAT_MSG_COMBAT_SELF_HITS", "You hit Boar for 12. unrelated"), nil, "anchored patterns")
eq(KM:Parse("CHAT_MSG_COMBAT_SELF_HITS", "You hit Boar for 12. (3 blocked) (2 absorbed) (glancing)").amount, 12, "multiple trailers")
eq(KM:Parse("CHAT_MSG_SPELL_SELF_DAMAGE", "Your |cff71d5ff|Hspell:75|h[Auto Shot]|h|r hits Boar for 12.").spell, "Auto Shot", "spell links")

-- Localized globals override English and positional printf slots remain semantic.
COMBATHITSELFOTHER = "%2$d points contre %1$s (100%%)."
locale = "frFR"
KM:BuildParser()
local translated = KM:Parse("CHAT_MSG_COMBAT_SELF_HITS", "37 points contre Sanglier (100%).")
eq(translated.amount, 37, "positional localized number")
eq(translated.target, "Sanglier", "positional localized target")
eq(KM.fallbackCount, 0, "do not guess English for non-English locales")
eq(KM:CompileFormat("%q"), nil, "unsupported placeholder")
COMBATHITSELFOTHER, locale = nil, "enUS"
KM:BuildParser()

local function emit(eventName, message, time)
  now = time
  KM.controller.scripts.OnEvent(KM.controller, eventName, message)
end
combat.player = true
emit("CHAT_MSG_COMBAT_SELF_HITS", "You hit Boar for 100.", 10)
emit("CHAT_MSG_COMBAT_SELF_HITS", "You hit Boar for 100.", 10)
eq(KM.active.damage, 200, "identical simultaneous hits both count")
emit("CHAT_MSG_SPELL_PARTY_DAMAGE", "Alice's Shadow Bolt crits Boar for 200 Shadow damage.", 11)
emit("CHAT_MSG_COMBAT_PET_HITS", "Wolf hits Boar for 40.", 12)
emit("CHAT_MSG_SPELL_PET_DAMAGE", "Imp's Firebolt hits Boar for 50 Fire damage.", 12)
emit("CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE", "Boar suffers 30 Nature damage from your Serpent Sting.", 14)
eq(KM.active.damage, 520, "group total")
eq(KM.overall.damage, 520, "overall includes active fight")
eq(KM.active.players.Bryce.damage, 270, "own pet merged with owner")
eq(KM.active.players.Alice.damage, 250, "party pet merged with owner")
eq(KM.active.players.Bryce.spells["Wolf: Melee"].damage, 40, "pet spell remains identifiable")
eq(KM.active.players.Alice.spells["Imp: Firebolt"].damage, 50, "party pet spell breakdown")
eq(KM.active.players.Alice.crits, 1, "crit accounting")

emit("CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS", "Boar hits you for 70.", 14)
emit("CHAT_MSG_COMBAT_FRIENDLYPLAYER_HITS", "Stranger hits Boar for 80.", 14)
emit("CHAT_MSG_SPELL_SELF_DAMAGE", "Your Fireball hits you for 90 Fire damage.", 14)
emit("CHAT_MSG_SPELL_PARTY_DAMAGE", "Alice's Shadow Bolt hits Bryce for 90 Shadow damage.", 14)
eq(KM.active.damage, 520, "exclude incoming, outsiders, self damage, and friendly damage")
eq(KM.stats.accepted, 6, "accepted event count")

-- Hiding only the window must not turn off its separate event/update controller.
SlashCmdList.KELDURNMETER("hide")
eq(KM.window.shown, false, "hide meter")
eq(KM.controller.shown, true, "recorder stays active")
emit("CHAT_MSG_COMBAT_SELF_HITS", "You hit Boar for 10.", 14)
eq(KM.active.damage, 530, "record while hidden")
SlashCmdList.KELDURNMETER("show")

now = 15
KM.controller.scripts.OnUpdate(KM.controller, 0.25)
combat.player = false
now = 19
KM.controller.scripts.OnUpdate(KM.controller, 0.25)
eq(KM.active, nil, "finish after inactivity outside group combat")
near(KM:Duration(KM.history[1], now), 5, "exclude grace from fight duration")
near(KM:Duration(KM.overall, now), 5, "completed duration added once")
eq(KM.history[1].damage, 530, "history total")

combat.party1 = true
emit("CHAT_MSG_COMBAT_PARTY_HITS", "Alice hits Spider for 60.", 100)
now = 109
KM:Tick(now)
eq(KM.active.damage, 60, "keep fight while another group member is in combat")
combat.party1 = false
now = 114
KM:Tick(now)
near(KM:Duration(KM.history[1], now), 9, "group combat duration")
near(KM:Duration(KM.overall, now), 14, "sum fights, not wall-clock idle time")
eq(KM.overall.damage, 590, "overall combines fights")

-- Repeated pet names cannot safely be assigned from 1.12's name-only messages.
names.partypet1 = "Wolf"
KM:RefreshRoster()
emit("CHAT_MSG_COMBAT_PET_HITS", "Wolf hits Spider for 999.", 115)
eq(KM.overall.damage, 590, "ambiguous pet excluded")
eq(KM.stats.ambiguous, 1, "ambiguous pet diagnostics")
names.partypet1 = "Imp"
KM:RefreshRoster()

-- Legacy handlers receive globals rather than explicit callback arguments.
now, event, arg1, this = 116, "CHAT_MSG_COMBAT_SELF_HITS", "You hit Spider for 10.", KM.controller
KM.controller.scripts.OnEvent()
eq(KM.overall.damage, 600, "legacy event callback")
arg1 = 0.25
KM.controller.scripts.OnUpdate()
event, arg1, this = nil, nil, nil

KM:SetView("overall")
KM:Render()
local firstPlayer = KM.rows[1].entry.name
KM.rows[1].scripts.OnClick(KM.rows[1])
eq(KM.selectedPlayer, firstPlayer, "click actor to inspect spells")
local spellRows, spellTotal = KM:Rows(KM.overall, firstPlayer)
eq(spellTotal, KM.overall.players[firstPlayer].damage, "spell breakdown total")
local summed = 0
for _, row in ipairs(spellRows) do summed = summed + row.damage end
eq(summed, spellTotal, "spell sum matches actor")
KM.rows[1].scripts.OnClick(KM.rows[1])
eq(KM.selectedPlayer, nil, "click spell to return to players")
this = KM.window
KM.window.scripts.OnDragStart()
eq(KM.window.moving, true, "legacy drag callback")
KM.window.x, KM.window.y = 123, -44
KM.window.scripts.OnDragStop()
eq(KM.db.x, 123, "persist horizontal position")
eq(KM.db.y, -44, "persist vertical position")
this = nil

-- Raid roster, deterministic ties, and pages for more than ten actors.
raidCount, partyCount = 12, 0
for index = 1, raidCount do
  names["raid" .. index], classes["raid" .. index] = "Raider" .. index, "MAGE"
end
KM:RefreshRoster()
for index = 1, raidCount do
  emit("CHAT_MSG_COMBAT_PARTY_HITS", "Raider" .. index .. " hits Boss for 100.", 117)
end
eq(KM.overall.damage, 1800, "raid names included")
local sorted = KM:Rows(KM.overall)
eq(sorted[1].damage >= sorted[2].damage, true, "rank by total")
KM.page = 2
KM:Render()
eq(KM.window.page.text, "2/2", "raid pagination")
eq(KM.rows[1].shown, true, "second page has entries")
KM.page = 99
KM:Render()
eq(KM.page, 2, "clamp page upper bound")
SlashCmdList.KELDURNMETER("history 99")
eq(KM.db.historyIndex, 10, "clamp history index")
SlashCmdList.KELDURNMETER("diag")
eq(table.getn(messages) > 1, true, "diagnostics printed")

-- Popup actions replace every footer button, including the page arrows.
eq(KM.window.menu.current.parent, KM.window.menu, "current action in popup")
eq(KM.window.history.parent, KM.window.menu, "history action in popup")
eq(KM.window.menu.overall.parent, KM.window.menu, "overall action in popup")
eq(KM.window.menu.reset.parent, KM.window.menu, "reset action in popup")
eq(KM.window.menu.previousPage.parent, KM.window.menu, "previous page in popup")
eq(KM.window.menu.nextPage.parent, KM.window.menu, "next page in popup")
for _, child in ipairs(KM.window.children) do
  if child.kind == "Button" and child.label then eq(child.label.text ~= "X", true, "no close button") end
end
KM.window.menuToggle.scripts.OnClick()
eq(KM.window.menu:IsShown(), true, "open hamburger menu")
KM.window.menuToggle.scripts.OnClick()
eq(KM.window.menu:IsShown(), false, "close hamburger menu")
KM.window.menu.overall.scripts.OnClick()
eq(KM.db.view, "overall", "overall menu action")
eq(KM.window.menu:IsShown(), false, "selection closes popup")
KM.window.menu.nextPage.scripts.OnClick()
eq(KM.page, 2, "menu next page")
KM.window.menu.previousPage.scripts.OnClick()
eq(KM.page, 1, "menu previous page")
KM.window.menu.current.scripts.OnClick()
eq(KM.db.view, "current", "current menu action")
KM.window.history.scripts.OnClick()
eq(KM.db.view, "history", "history menu action")
KM.window.menu.overall.scripts.OnClick()

-- Simulate a native resize: content reflows, top-left stays fixed, size persists.
local left, top = KM.window:GetLeft(), KM.window:GetTop()
KM.window.menuToggle.scripts.OnClick()
this = KM.window.resize
KM.window.resize.scripts.OnDragStart()
eq(KM.window.sizing, "BOTTOMRIGHT", "native bottom-right resize")
eq(KM.window.menu:IsShown(), false, "close popup while resizing")
KM.window:SetWidth(600)
KM.window:SetHeight(424)
near(KM.window:GetLeft(), left, "fixed left edge during resize")
near(KM.window:GetTop(), top, "fixed top edge during resize")
eq(KM.visibleRows, 16, "larger window shows more rows")
eq(KM.window.page.text, "1/1", "page count follows available rows")
eq(KM.rows[14].shown, true, "larger window reveals raid members")
eq(KM.rows[15].shown, false, "unused row stays hidden")
eq(KM.rows[1]:GetWidth(), 578, "bars follow window width")
eq(KM.rows[1].name:GetRight() < KM.rows[1].value:GetLeft(), true, "name and value do not overlap")
KM.window.resize.scripts.OnDragStop()
eq(KM.window.sizing, nil, "end native resize")
eq(KM.db.width, 600, "save resized width")
eq(KM.db.height, 424, "save resized height")
near(KM.window:GetLeft(), left, "keep left edge after save")
near(KM.window:GetTop(), top, "keep top edge after save")

KM.window.resize.scripts.OnDragStart()
KM.window:SetWidth(100)
KM.window:SetHeight(100)
eq(KM.window:GetWidth(), 320, "minimum readable width")
eq(KM.window:GetHeight(), 200, "minimum readable height")
eq(KM.visibleRows, 5, "smaller window uses fewer rows")
eq(KM.window.page.text, "1/3", "smaller window increases page count")
eq(KM.rows[6].shown, false, "rows stay inside shorter window")
KM.window.menu.nextPage.scripts.OnClick()
eq(KM.rows[1].name.text, "6. " .. KM.rows[1].entry.name, "page offset follows resized row count")
KM.window:SetWidth(9999)
KM.window:SetHeight(9999)
eq(KM.window:GetWidth(), 900, "maximum window width")
eq(KM.visibleRows, 40, "largest window row capacity")
eq(KM.page, 1, "larger resize clamps current page")
KM.window:SetWidth(360)
KM.window:SetHeight(304)
KM.window.resize.scripts.OnDragStop()
this = nil
KM.window.menuToggle.scripts.OnClick()
SlashCmdList.KELDURNMETER("hide")
eq(KM.window.menu:IsShown(), false, "hide also closes popup")
SlashCmdList.KELDURNMETER("show")

-- A long session has bounded encounter history and exact summed damage.
SlashCmdList.KELDURNMETER("reset")
raidCount, partyCount = 0, 1
KM:RefreshRoster()
for index = 1, 12 do
  emit("CHAT_MSG_COMBAT_SELF_HITS", "You hit Boar for 10.", 200 + index * 10)
  now = now + 6
  KM:Tick(now)
end
eq(table.getn(KM.history), 10, "bounded history")
eq(KM.overall.damage, 120, "history trimming preserves overall")
eq(KM:Duration(KM.overall, now), 12, "one-second minimum for instant encounters")
eq(KM.history[1].start, 320, "newest history first")
emit("CHAT_MSG_COMBAT_PET_HITS", "Wolf hits Boar for 5.", 350)
combat.pet, now = true, 357
KM:Tick(now)
eq(KM.active.damage, 5, "pet combat keeps encounter active")
combat.pet, now = false, 363
KM:Tick(now)
eq(KM.active, nil, "pet encounter ends outside combat")
eq(KM:Duration(KM.history[1], now), 7, "include observed pet combat time")
KM:OnCombat("CHAT_MSG_COMBAT_SELF_HITS", "unrecognized client format")
KM:OnCombat("CHAT_MSG_COMBAT_SELF_HITS", "unrecognized client format")
eq(table.getn(KM.stats.samples), 1, "unique unmatched diagnostic sample")
SlashCmdList.KELDURNMETER("reset")
eq(KM.overall.damage, 0, "reset overall")
eq(KM.active, nil, "reset active")
eq(table.getn(KM.history), 0, "reset history")
eq(KM.db.metric, "dps", "reset preserves preferences")
SlashCmdList.KELDURNMETER("position")
eq(KM.window.x, 240, "recover window position")
eq(KM.stats.received > KM.stats.accepted, true, "diagnostics retain excluded events")
KM.window.menuToggle.scripts.OnClick()
KM.window.menu.reset.scripts.OnClick()
eq(KM.overall.damage, 0, "reset menu action")
eq(KM.window.menu:IsShown(), false, "reset closes popup")

-- Reload through the normal startup path to check saved geometry restoration.
KeldurnMeterDB.width, KeldurnMeterDB.height = 480, 384
dofile("Parser.lua")
dofile("Core.lua")
dofile("UI.lua")
KeldurnMeter:Initialize()
eq(KeldurnMeter.window:GetWidth(), 480, "restore saved width on reload")
eq(KeldurnMeter.window:GetHeight(), 384, "restore saved height on reload")
eq(KeldurnMeter.visibleRows, 14, "restore row layout on reload")
eq(KeldurnMeter.db.metric, "dps", "upgrade preserves metric preference")
print("PASS: " .. passed .. " assertions; vanilla parsing, accounting, pets, segments, roster, and UI callbacks.")
