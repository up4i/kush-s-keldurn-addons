local KM = KeldurnMeter
KM.history = {}
KM.stats = { received = 0, parsed = 0, accepted = 0, ignored = 0, unmatched = 0, ambiguous = 0, samples = {} }
KM.unitsByName, KM.petsByName, KM.ambiguousPets, KM.groupUnits = {}, {}, {}, {}
KM.historyLimit, KM.idleSeconds = 10, 5

local function newSegment(label, now)
  return { label = label, start = now, lastDamage = now, lastCombat = now, damage = 0, players = {} }
end
KM.overall = newSegment("Overall", 0)
KM.overall.duration = 0

function KM:Print(message)
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff74c7ffDamage!:|r " .. message) end
end

function KM:RefreshRoster()
  local players, pets, ambiguous, units = {}, {}, {}, {}
  local function addPlayer(unit, petUnit)
    local name = UnitName(unit)
    if not name or name == "Unknown" or name == UNKNOWN then return end
    local _, class = UnitClass(unit)
    players[name] = { name = name, class = class or "UNKNOWN", unit = unit }
    table.insert(units, unit)
    local pet = UnitName(petUnit)
    if pet and pet ~= "Unknown" and pet ~= UNKNOWN then
      table.insert(units, petUnit)
      if pets[pet] and pets[pet].owner ~= name then
        ambiguous[pet] = true
      else
        pets[pet] = { owner = name, name = pet }
      end
    end
  end
  addPlayer("player", "pet")
  local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0
  if raidCount > 0 then
    for index = 1, raidCount do addPlayer("raid" .. index, "raidpet" .. index) end
  else
    local partyCount = GetNumPartyMembers and GetNumPartyMembers() or 0
    for index = 1, partyCount do addPlayer("party" .. index, "partypet" .. index) end
  end
  for pet in pairs(pets) do if players[pet] then ambiguous[pet] = true end end
  self.unitsByName, self.petsByName, self.ambiguousPets, self.groupUnits = players, pets, ambiguous, units
end

function KM:GroupInCombat()
  if not UnitAffectingCombat then return false end
  for _, unit in ipairs(self.groupUnits) do
    if UnitAffectingCombat(unit) then return true end
  end
  return false
end

function KM:Initialize()
  if self.initialized then return end
  if type(KeldurnMeterDB) ~= "table" then KeldurnMeterDB = {} end
  self.db = KeldurnMeterDB
  if self.db.metric ~= "dps" then self.db.metric = "damage" end
  if self.db.view ~= "overall" then self.db.view = "current" end
  self.db.historyIndex = 1
  self:BuildParser()
  self:RefreshRoster()
  self.initialized = true
  if self.CreateWindow then self:CreateWindow() end
  self:Print("v" .. self.version .. " loaded. /damage help; click a player for spells.")
end

function KM:Duration(segment, now)
  if not segment then return 0 end
  if segment == self.overall then
    local duration = segment.duration
    if self.active then duration = duration + self:Duration(self.active, now) end
    return duration
  end
  return math.max(1, (segment.finish or now or GetTime()) - segment.start)
end

function KM:FinishFight()
  local segment = self.active
  if not segment then return end
  -- Do not count the inactivity grace period as encounter time.
  segment.finish = math.max(segment.lastDamage, segment.lastCombat)
  self.overall.duration = self.overall.duration + self:Duration(segment, segment.finish)
  table.insert(self.history, 1, segment)
  if table.getn(self.history) > self.historyLimit then table.remove(self.history) end
  self.active = nil
end

function KM:Tick(now)
  if not self.initialized then return end
  if not self.rosterAt or now - self.rosterAt >= 1 then
    self:RefreshRoster()
    self.rosterAt = now
  end
  if self.active then
    if self:GroupInCombat() then
      self.active.lastCombat = now
    elseif now - self.active.lastDamage >= self.idleSeconds then
      self:FinishFight()
    end
  end
end

local function addDamage(segment, player, spellName, record)
  local actor = segment.players[player.name]
  if not actor then
    actor = { name = player.name, class = player.class, damage = 0, hits = 0, crits = 0, spells = {} }
    segment.players[player.name] = actor
  end
  local spell = actor.spells[spellName]
  if not spell then
    spell = { name = spellName, damage = 0, hits = 0, crits = 0 }
    actor.spells[spellName] = spell
  end
  segment.damage = segment.damage + record.amount
  actor.damage, actor.hits = actor.damage + record.amount, actor.hits + 1
  spell.damage, spell.hits = spell.damage + record.amount, spell.hits + 1
  if record.critical then
    actor.crits, spell.crits = actor.crits + 1, spell.crits + 1
  end
end

function KM:Record(record, now)
  if not record.source or not record.target or not record.amount or record.amount <= 0 then return false end
  if self.ambiguousPets[record.source] then
    self.stats.ambiguous = self.stats.ambiguous + 1
    return false
  end
  local pet = self.petsByName[record.source]
  local player = self.unitsByName[pet and pet.owner or record.source]
  if not player then return false end
  -- Incoming damage and damage against our own group are not damage done.
  if self.unitsByName[record.target] or self.petsByName[record.target] then return false end
  if self.active and now - self.active.lastDamage >= self.idleSeconds and not self:GroupInCombat() then
    self:FinishFight()
  end
  if not self.active then self.active = newSegment(record.target, now) end
  self.active.lastDamage = now
  local spellName = pet and (pet.name .. ": " .. record.spell) or record.spell
  addDamage(self.active, player, spellName, record)
  addDamage(self.overall, player, spellName, record)
  return true
end

function KM:OnCombat(combatEvent, message)
  if type(message) ~= "string" then return end
  self:Initialize()
  self.stats.received = self.stats.received + 1
  local record = self:Parse(combatEvent, message)
  if record then
    self.stats.parsed = self.stats.parsed + 1
    if self:Record(record, GetTime()) then
      self.stats.accepted = self.stats.accepted + 1
    else
      self.stats.ignored = self.stats.ignored + 1
    end
  else
    self.stats.unmatched = self.stats.unmatched + 1
    local sample = combatEvent .. ": " .. self:CleanMessage(message)
    local found = false
    for _, old in ipairs(self.stats.samples) do if old == sample then found = true end end
    if not found and table.getn(self.stats.samples) < 3 then table.insert(self.stats.samples, sample) end
  end
end

function KM:SelectedSegment()
  if self.db.view == "overall" then return self.overall end
  if self.db.view == "history" then return self.history[self.db.historyIndex] end
  return self.active or self.history[1]
end

function KM:Rows(segment, playerName)
  local rows, total = {}, 0
  if not segment then return rows, total end
  local actor = playerName and segment.players[playerName]
  if playerName and not actor then return rows, total end
  local entries = actor and actor.spells or segment.players
  total = actor and actor.damage or segment.damage
  for _, entry in pairs(entries) do table.insert(rows, entry) end
  table.sort(rows, function(a, b)
    if a.damage == b.damage then return a.name < b.name end
    return a.damage > b.damage
  end)
  return rows, total
end

function KM:Reset()
  self.active, self.history = nil, {}
  self.overall = newSegment("Overall", 0)
  self.overall.duration = 0
  self.selectedPlayer, self.page = nil, 1
  self.db.historyIndex, self.db.view = 1, "current"
  self:Print("Fight and overall totals reset.")
end

function KM:Diagnostics()
  self:Print("v" .. self.version .. "; locale " .. self.locale .. "; formats " .. self.formatCount ..
    " (" .. self.fallbackCount .. " English fallbacks).")
  self:Print("Events " .. self.stats.received .. "; parsed " .. self.stats.parsed ..
    "; counted " .. self.stats.accepted .. "; ignored " .. self.stats.ignored .. "; unmatched " .. self.stats.unmatched .. ".")
  local players, pets = 0, 0
  for _ in pairs(self.unitsByName) do players = players + 1 end
  for _ in pairs(self.petsByName) do pets = pets + 1 end
  self:Print("Roster " .. players .. " players, " .. pets .. " pets; ambiguous pet events skipped " .. self.stats.ambiguous .. ".")
  if self.registrationFailures then
    for _, name in ipairs(self.registrationFailures) do self:Print("Event registration failed: " .. name) end
  end
  for _, sample in ipairs(self.stats.samples) do self:Print("Unmatched: " .. sample) end
end

function KM:SetView(view, index)
  self.db.view, self.db.historyIndex = view, index or 1
  self.selectedPlayer, self.page = nil, 1
end

function KM:Command(message)
  self:Initialize()
  local _, _, command, value = string.find(string.lower(message or ""), "^(%S+)%s*(.-)%s*$")
  if not command then
    self.db.hidden = not self.db.hidden
  elseif command == "show" then self.db.hidden = false
  elseif command == "hide" then self.db.hidden = true
  elseif command == "damage" or command == "dps" then self.db.metric = command
  elseif command == "current" or command == "overall" then self:SetView(command)
  elseif command == "last" then self:SetView("history", 1)
  elseif command == "history" then self:SetView("history", math.max(1, math.min(self.historyLimit, math.floor(tonumber(value) or 1))))
  elseif command == "reset" then self:Reset()
  elseif command == "diag" then self:Diagnostics()
  elseif command == "position" then
    self.db.x, self.db.y = nil, nil
    if self.window then self:PlaceWindow() end
    self.db.hidden = false
  else
    self:Print("/damage or /dam: show | hide | damage | dps | current | last | history 1-10 | overall | reset | position | diag")
  end
  if self.Render then self:Render() end
end
