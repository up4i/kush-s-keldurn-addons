local KM = KeldurnMeter
local MAX_ROWS, ROW_HEIGHT, WIDTH, HEIGHT = 40, 20, 360, 304
local MIN_WIDTH, MIN_HEIGHT, MAX_SIZE = 320, 200, 900
local ROW_TOP, FOOTER_HEIGHT = 64, 34
local colors = {
  WARRIOR = { 0.78, 0.61, 0.43 }, MAGE = { 0.41, 0.80, 0.94 },
  ROGUE = { 1.00, 0.96, 0.41 }, DRUID = { 1.00, 0.49, 0.04 },
  HUNTER = { 0.67, 0.83, 0.45 }, SHAMAN = { 0.14, 0.60, 1.00 },
  PRIEST = { 1.00, 1.00, 1.00 }, WARLOCK = { 0.58, 0.51, 0.79 },
  PALADIN = { 0.96, 0.55, 0.73 }, UNKNOWN = { 0.45, 0.65, 0.85 }
}

local function text(parent, size, justify)
  local label = parent:CreateFontString(nil, "OVERLAY")
  label:SetFont("Fonts\\FRIZQT__.TTF", size)
  label:SetJustifyH(justify or "LEFT")
  label:SetTextColor(0.93, 0.94, 0.97)
  return label
end

local function button(parent, label, x, y, width, action)
  local control = CreateFrame("Button", nil, parent)
  control:SetWidth(width)
  control:SetHeight(22)
  control:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  control:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background" })
  control:SetBackdropColor(0.17, 0.20, 0.25, 0.95)
  control.label = text(control, 11, "CENTER")
  control.label:SetAllPoints(control)
  control.label:SetText(label)
  control:SetScript("OnClick", action)
  return control
end

local function number(value)
  if value >= 1000000 then return string.format("%.2fm", value / 1000000) end
  if value >= 10000 then return string.format("%.1fk", value / 1000) end
  return string.format("%.0f", value)
end

function KM:PlaceWindow()
  self.window:ClearAllPoints()
  self.window:SetPoint("CENTER", UIParent, "CENTER", tonumber(self.db.x) or 240, tonumber(self.db.y) or -80)
end

function KM:SaveWindowGeometry()
  local x, y = self.window:GetCenter()
  local parentX, parentY = UIParent:GetCenter()
  if x and y and parentX and parentY then self.db.x, self.db.y = x - parentX, y - parentY end
  self.db.width, self.db.height = self.window:GetWidth(), self.window:GetHeight()
end

function KM:LayoutWindow()
  local window = self.window
  local width, height = window:GetWidth(), window:GetHeight()
  self.visibleRows = math.max(1, math.min(MAX_ROWS, math.floor((height - ROW_TOP - FOOTER_HEIGHT) / ROW_HEIGHT)))
  window.context:SetWidth(width - 110)
  window.empty:SetWidth(width - 40)
  window.empty:ClearAllPoints()
  window.empty:SetPoint("TOPLEFT", window, "TOPLEFT", 20, -ROW_TOP - (self.visibleRows * ROW_HEIGHT - 65) / 2)
  window.total:SetWidth(width - 105)
  for _, row in ipairs(self.rows) do
    row:SetWidth(width - 22)
    row.name:SetWidth(width - 155)
  end
end

function KM:CreateWindow()
  if self.window then return end
  local window = CreateFrame("Frame", "KeldurnMeterWindow", UIParent)
  self.window, self.page, self.rows = window, 1, {}
  window:SetWidth(math.max(MIN_WIDTH, math.min(MAX_SIZE, tonumber(self.db.width) or WIDTH)))
  window:SetHeight(math.max(MIN_HEIGHT, math.min(MAX_SIZE, tonumber(self.db.height) or HEIGHT)))
  window:SetFrameStrata("MEDIUM")
  window:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16,
    edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 }
  })
  window:SetBackdropColor(0.055, 0.065, 0.09, 0.94)
  window:SetBackdropBorderColor(0.30, 0.38, 0.47, 1)
  window:SetMovable(true)
  window:SetResizable(true)
  window:SetMinResize(MIN_WIDTH, MIN_HEIGHT)
  window:SetMaxResize(MAX_SIZE, MAX_SIZE)
  window:EnableMouse(true)
  if window.SetClampedToScreen then window:SetClampedToScreen(true) end
  window:RegisterForDrag("LeftButton")
  window:SetScript("OnDragStart", function(frame) (frame or this):StartMoving() end)
  window:SetScript("OnDragStop", function(frame)
    frame = frame or this
    frame:StopMovingOrSizing()
    KM:SaveWindowGeometry()
  end)
  self:PlaceWindow()

  window.title = text(window, 14)
  window.title:SetPoint("TOPLEFT", window, "TOPLEFT", 11, -12)
  window.title:SetText("Damage!")
  window.menuToggle = button(window, "", 0, -7, 22, function()
    if window.menu:IsShown() then window.menu:Hide() else window.menu:Show() end
  end)
  window.menuToggle:ClearAllPoints()
  window.menuToggle:SetPoint("TOPRIGHT", window, "TOPRIGHT", -11, -7)
  -- Draw the hamburger with vanilla textures rather than a font-dependent glyph.
  for index = 1, 3 do
    local line = window.menuToggle:CreateTexture(nil, "OVERLAY")
    line:SetTexture("Interface\\Buttons\\WHITE8X8")
    line:SetWidth(14)
    line:SetHeight(2)
    line:SetPoint("TOPLEFT", window.menuToggle, "TOPLEFT", 4, -5 - (index - 1) * 5)
  end
  window.context = button(window, "", 11, -32, 250, function()
    KM.selectedPlayer, KM.page = nil, 1
    KM:Render()
  end)
  window.context:SetBackdropColor(0, 0, 0, 0)
  window.context.label:SetJustifyH("LEFT")
  window.metric = button(window, "Damage", 272, -32, 77, function()
    KM.db.metric = KM.db.metric == "damage" and "dps" or "damage"
    KM:Render()
  end)
  window.metric:ClearAllPoints()
  window.metric:SetPoint("TOPRIGHT", window, "TOPRIGHT", -11, -32)

  for index = 1, MAX_ROWS do
    local row = CreateFrame("Button", nil, window)
    row:SetWidth(WIDTH - 22)
    row:SetHeight(ROW_HEIGHT - 2)
    row:SetPoint("TOPLEFT", window, "TOPLEFT", 11, -ROW_TOP - (index - 1) * ROW_HEIGHT)
    row:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background" })
    row:SetBackdropColor(0.13, 0.15, 0.19, 0.85)
    row.bar = CreateFrame("StatusBar", nil, row)
    row.bar:SetAllPoints(row)
    row.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    row.bar:SetMinMaxValues(0, 1)
    row.bar:EnableMouse(false)
    row.name = text(row.bar, 11)
    row.name:SetPoint("LEFT", row.bar, "LEFT", 5, 0)
    row.name:SetWidth(205)
    row.name:SetHeight(ROW_HEIGHT - 2)
    row.value = text(row.bar, 11, "RIGHT")
    row.value:SetPoint("RIGHT", row.bar, "RIGHT", -5, 0)
    row.value:SetWidth(120)
    row.value:SetHeight(ROW_HEIGHT - 2)
    row:SetScript("OnClick", function(frame)
      frame = frame or this
      if not frame.entry then return end
      if KM.selectedPlayer then KM.selectedPlayer = nil else KM.selectedPlayer = frame.entry.name end
      KM.page = 1
      KM:Render()
    end)
    table.insert(self.rows, row)
  end

  window.empty = text(window, 12, "CENTER")
  window.empty:SetWidth(WIDTH - 40)
  window.empty:SetHeight(65)
  window.empty:SetText("Waiting for damage.\nFight an enemy, then check /damage diag\nif the meter stays empty.")
  window.total = text(window, 11)
  window.total:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 11, 11)
  window.total:SetHeight(18)
  window.page = text(window, 10, "CENTER")
  window.page:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -30, 13)
  window.page:SetWidth(55)
  window.page:SetHeight(14)
  local menu = CreateFrame("Frame", nil, window)
  window.menu = menu
  menu:SetWidth(132)
  menu:SetHeight(144)
  menu:SetPoint("TOPRIGHT", window, "TOPRIGHT", -11, -31)
  menu:SetFrameStrata("DIALOG")
  menu:EnableMouse(true)
  menu:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
  })
  menu:SetBackdropColor(0.055, 0.065, 0.09, 1)
  menu.current = button(menu, "Current", 8, -8, 116, function()
    KM:SetView("current"); menu:Hide(); KM:Render()
  end)
  window.history = button(menu, "Fights", 8, -34, 116, function()
    local count = table.getn(KM.history)
    local index = KM.db.view == "history" and KM.db.historyIndex + 1 or 1
    if index > count then index = 1 end
    KM:SetView("history", index)
    menu:Hide()
    KM:Render()
  end)
  menu.overall = button(menu, "Overall", 8, -60, 116, function()
    KM:SetView("overall"); menu:Hide(); KM:Render()
  end)
  menu.reset = button(menu, "Reset", 8, -86, 116, function()
    KM:Reset(); menu:Hide(); KM:Render()
  end)
  menu.previousPage = button(menu, "< Page", 8, -112, 56, function()
    KM.page = KM.page - 1; menu:Hide(); KM:Render()
  end)
  menu.nextPage = button(menu, "Page >", 68, -112, 56, function()
    KM.page = KM.page + 1; menu:Hide(); KM:Render()
  end)
  menu:Hide()

  window.resize = CreateFrame("Button", nil, window)
  window.resize:SetWidth(20)
  window.resize:SetHeight(20)
  window.resize:SetPoint("BOTTOMRIGHT", window, "BOTTOMRIGHT", -3, 3)
  local grip = window.resize:CreateTexture(nil, "OVERLAY")
  grip:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  grip:SetAllPoints(window.resize)
  window.resize:RegisterForDrag("LeftButton")
  window.resize:SetScript("OnDragStart", function()
    menu:Hide()
    -- Keep the top-left corner still as the bottom-right corner moves.
    local left, top = window:GetLeft(), window:GetTop()
    window:ClearAllPoints()
    window:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
    window:StartSizing("BOTTOMRIGHT")
  end)
  window.resize:SetScript("OnDragStop", function()
    window:StopMovingOrSizing()
    KM:SaveWindowGeometry()
    KM:PlaceWindow()
    KM:LayoutWindow()
    KM:Render()
  end)
  window:SetScript("OnSizeChanged", function() KM:LayoutWindow(); KM:Render() end)
  self:LayoutWindow()
  self:Render()
end

function KM:Render()
  if not self.window then return end
  local window = self.window
  if self.db.hidden then window.menu:Hide(); window:Hide(); return end
  window:Show()
  local segment = self:SelectedSegment()
  -- A selected player may be absent from a newly started encounter.
  if self.selectedPlayer and (not segment or not segment.players[self.selectedPlayer]) then
    self.selectedPlayer, self.page = nil, 1
  end
  local rows, total = self:Rows(segment, self.selectedPlayer)
  local count = table.getn(rows)
  local pages = math.max(1, math.ceil(count / self.visibleRows))
  self.page = math.max(1, math.min(pages, self.page or 1))
  local duration = self:Duration(segment, GetTime())
  local heading = "Current"
  if self.db.view == "overall" then heading = "Overall"
  elseif self.db.view == "history" then heading = "Fight " .. self.db.historyIndex
  elseif segment and not self.active then heading = "Last fight" end
  local description = segment and segment.label or "No fights yet"
  if self.selectedPlayer then description = "< Players: " .. self.selectedPlayer end
  window.context.label:SetText(heading .. " | " .. string.sub(description, 1, 23))
  window.metric.label:SetText(self.db.metric == "dps" and "DPS" or "Damage")
  window.history.label:SetText(self.db.view == "history" and ("Fight " .. self.db.historyIndex) or "Fights")
  window.page:SetText(self.page .. "/" .. pages)
  local dps = duration > 0 and total / duration or 0
  window.total:SetText(number(total) .. " damage | " .. number(dps) .. " DPS | " .. string.format("%.1fs", duration))
  local top = rows[1] and rows[1].damage or 1
  local selectedActor = segment and self.selectedPlayer and segment.players[self.selectedPlayer]
  for index, row in ipairs(self.rows) do
    local rank = (self.page - 1) * self.visibleRows + index
    local entry = index <= self.visibleRows and rows[rank] or nil
    row.entry = entry
    if entry then
      row:Show()
      local color = colors[(selectedActor and selectedActor.class) or entry.class] or colors.UNKNOWN
      row.bar:SetStatusBarColor(color[1], color[2], color[3], 0.70)
      row.bar:SetValue(entry.damage / math.max(1, top))
      row.name:SetText(rank .. ". " .. entry.name)
      local value = self.db.metric == "dps" and entry.damage / math.max(1, duration) or entry.damage
      local percent = total > 0 and 100 * entry.damage / total or 0
      row.value:SetText(number(value) .. string.format(" (%.1f%%)", percent))
    else
      row:Hide()
    end
  end
  if count == 0 then window.empty:Show() else window.empty:Hide() end
end

SLASH_KELDURNMETER1 = "/damage"
SLASH_KELDURNMETER2 = "/dam"
SlashCmdList["KELDURNMETER"] = function(message) KM:Command(message) end

-- This controller stays shown when the meter window is hidden, so it keeps recording.
KM.controller = CreateFrame("Frame", "KeldurnMeterEvents", UIParent)
KM.registrationFailures = {}
local function register(name)
  local success = pcall(function() KM.controller:RegisterEvent(name) end)
  if not success then table.insert(KM.registrationFailures, name) end
end
for combatEvent in pairs(KM.combatEvents) do register(combatEvent) end
for _, name in ipairs({ "ADDON_LOADED", "VARIABLES_LOADED", "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD",
  "PARTY_MEMBERS_CHANGED", "RAID_ROSTER_UPDATE", "UNIT_PET" }) do register(name) end
KM.controller:SetScript("OnEvent", function(frame, eventName, message)
  eventName, message = eventName or event, message or arg1
  if KM.combatEvents[eventName] then
    KM:OnCombat(eventName, message)
  elseif eventName == "ADDON_LOADED" then
    if message == "KeldurnMeter" then KM:Initialize() end
  elseif eventName == "VARIABLES_LOADED" or eventName == "PLAYER_LOGIN" then
    KM:Initialize()
  elseif eventName == "PLAYER_ENTERING_WORLD" then
    KM:Initialize()
    KM:BuildParser()
    KM:RefreshRoster()
  elseif KM.initialized then
    KM:RefreshRoster()
  end
end)
KM.controller:SetScript("OnUpdate", function(frame, elapsed)
  KM.updateElapsed = (KM.updateElapsed or 0) + (elapsed or arg1 or 0)
  if KM.updateElapsed < 0.25 then return end
  KM.updateElapsed = 0
  KM:Tick(GetTime())
  KM:Render()
end)
