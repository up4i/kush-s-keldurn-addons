# Damage! 0.1.2

An original, Details-inspired damage meter built for the **vanilla 1.12 addon API**
exposed by Keldurn. This is a first playable prototype, with editable Lua source.
It is a separate addon, with no dependency on Details, Ace, or other addon libraries.

## Install in Keldurn

1. Download `Damage-0.1.2.zip` and keep it as a ZIP for the addon installer.
2. At character selection, open **AddOns** and use the option to install an addon
   ZIP or folder. Select this ZIP.
3. Enable **Damage!**, choose **Okay**, then enter the world.
4. Fight a few enemies. The window should begin recording automatically.

If you install manually, put the included `KeldurnMeter` folder in the addon
directory identified by Keldurn's AddOns screen, then choose **Refresh** and enable
it. The `.toc` file must sit directly inside that folder. On a stock vanilla client,
the corresponding path is `Interface/AddOns/KeldurnMeter/KeldurnMeter.toc`.

After replacing addon files, reload the UI or restart the client. Do not install
this into the launcher's executable directory unless the AddOns screen identifies
that directory as the addon location.

## Using the meter

- Drag the window by its header or border to move it.
- Drag the **bottom-right corner** to resize its width and height. Bars adjust to
  the width, and taller windows show more rows. Position, size, and display
  preferences are saved.
- Click the **hamburger icon at the top right** to open or close the menu.
  Choose Current, Fights, Overall, Reset, or a page arrow there. Choosing an
  action closes the menu.
- Click **Damage / DPS** to switch metrics. Every actor uses the same encounter duration.
- Click a player to see their spells, including separately labelled pet attacks.
  Click the header or a spell row to return to the player list.
- **Current** in the menu shows the active encounter, or the last encounter if you are out of combat.
- **Fights** in the menu cycles through the ten most recent completed encounters, newest first.
- **Overall** in the menu combines the session's damage and encounter time.
- The menu's page arrows show additional players or spells, including larger raid rosters.
- **Reset** in the menu clears combat totals and fight history, while keeping display preferences.
- Use `/damage hide` or `/dam` to hide the window. Recording continues while it is hidden.

When upgrading from Keldurn Meter 0.1.0, replace the existing addon rather than
installing a second copy. The internal folder remains `KeldurnMeter`, so your
saved position and display preferences are retained. The AddOns list and meter
window now show **Damage!**.

| Command | Action |
| --- | --- |
| `/damage` / `/dam` | Show or hide the meter |
| `/damage show` / `/damage hide` | Set window visibility |
| `/damage damage` / `/damage dps` | Select a metric |
| `/damage current` / `/damage last` | Active or most recent completed encounter |
| `/damage history 3` | Third most recent completed encounter; accepts 1–10 |
| `/damage overall` | All damage recorded in this UI session |
| `/damage reset` | Clear session totals and history |
| `/damage position` | Restore the default position and show the window |
| `/damage diag` | Print parser, event, roster, and unmatched-message diagnostics |
| `/damage help` | List commands |

Every subcommand also works with `/dam`, for example `/dam reset` and `/dam diag`.

## What is measured

Melee hits, named spell hits, critical hits, damage-over-time ticks, and damage
shields are parsed from the old `CHAT_MSG_COMBAT_*` / `CHAT_MSG_SPELL_*` events.
Player, party, and raid damage is counted; nearby outsiders and incoming damage
are excluded. Current group pets are merged into their owners' totals.

A fight starts with the first counted hit. It ends after at least five seconds
without counted damage, once no known group player or pet is in combat. Its
duration runs from that first hit to the last hit or last observed group combat
time, with a one-second minimum. The five-second grace period is excluded when
the encounter closes. DPS during that grace period is provisional.

Overall DPS divides all counted damage by the sum of encounter durations,
including the current encounter while it is active. Time spent idle between
fights is excluded. Successful damage events and critical hit counts are retained
in the Lua data for future displays; misses are not counted as successful hits.

## Limits of this first version

- **Live Keldurn testing is still needed.** This version was checked against the
  API and combat-event names in the supplied KeldurnGame build 8 and exercised in
  a standalone Lua 5.0 test harness. That does not establish that Keldurn emits
  every event correctly or renders every frame identically to the original client.
- Vanilla logs only reveal combat within the client's observable range. There is
  no group synchronization yet, so a full raid may be undercounted. This addon
  does not alter combat-log distance settings.
- Attribution is based on names, not GUIDs. When two group pets have the same
  name, their events are deliberately skipped instead of assigned to the wrong
  owner. Unrecognized, out-of-range, or departed pets can also be missed.
- Only position, size, visibility, and metric preferences persist. Combat totals and
  history reset when you reload the UI or restart. Overall is a session total.
- Healing, threat, dispels, deaths, boss detection, encounter merging, and network
  synchronization are outside this first version. A fight name uses its first target.
- Damage shields are grouped by school because these old messages omit the spell name.
- Client-localized format globals are preferred. English fallback formats are
  only enabled when `GetLocale()` reports `enUS`; incomplete non-English globals
  will produce unmatched messages rather than guessed totals.

## First in-game check

1. Use `/damage reset`, then attack several enemies with melee or ranged attacks and a
   named ability. If you have a pet, let it attack too.
2. Check that damage appears, click your name, and confirm that the expected spells
   and pet attacks appear.
3. Stop combat, wait five seconds, and check **Fights** and **Overall** in the hamburger menu.
4. Try the same test with one party member nearby.
5. Run `/damage diag`. If anything is missing, share the diagnostic output and any
   addon Lua error. The output includes up to three distinct unmatched messages.

If the addon does not load, check that it is enabled in AddOns and the folder
name is `KeldurnMeter`. If `/damage` is unrecognized, share the load error; diagnostics
cannot run until the addon loads.

## Development

- `Parser.lua`: localized format compiler and vanilla event/message decoding.
- `Core.lua`: roster, pet ownership, segments, totals, diagnostics, and commands.
- `UI.lua`: native frame window and legacy/explicit callback support.
- `KeldurnMeter.toc`: loader metadata and saved-variable declaration.
- `tests/test.lua`: independent combat examples plus accounting and UI lifecycle tests.

Run tests from this folder with Lua 5.0 or 5.1:

```text
lua tests/test.lua
```

The tests include all 35 supported message formats, positional localized
placeholders, absorb/block trailers, identical simultaneous hits, pet attribution
and ambiguity, incoming-damage filtering, group combat timing, bounded history,
raid pagination, resize layout and saved dimensions, menu actions, saved preferences,
and recording while hidden. Their UI stand-in
checks callback behavior; it does not verify the client's graphics.

Keep runtime code compatible with Lua 5.0: use `table.getn` and `string.find`;
avoid the length operator, `string.match`, modern combat-log APIs, and `UnitGUID`.
The immediate next step is checking the in-game event output. Group synchronization
should follow once local parsing and attribution are confirmed.

The upstream [Details repository](https://github.com/Tercioo/Details-Damage-Meter)
is the feature reference. The upstream
[ShaguDPS vanilla parser](https://github.com/shagu/ShaguDPS/blob/master/parser-vanilla.lua)
was consulted for vanilla format names and their argument meanings. No third-party
addon implementation or artwork is included in this package.
