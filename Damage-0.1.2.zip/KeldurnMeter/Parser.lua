-- Original implementation. Use Lua 5.0 syntax and vanilla combat chat events.
KeldurnMeter = { version = "0.1.2" }
local KM = KeldurnMeter
local SELF = 0

-- Each format's numbered slots have the order defined by vanilla GlobalStrings.
-- Read the client's localized globals first; English is only a fallback on enUS.
local definitions = { melee = {}, spell = {}, periodic = {}, shield = {} }
local function define(family, key, english, source, spell, target, amount, school, crit)
  table.insert(definitions[family], {
    key = key, english = english, source = source, spell = spell,
    target = target, amount = amount, school = school, crit = crit
  })
end

local sides = {
  { suffix = "SELFOTHER", plain = "You %s %%s for %%d.",
    school = "You %s %%s for %%d %%s damage.", source = SELF, target = 1, amount = 2, schoolSlot = 3 },
  { suffix = "OTHERSELF", plain = "%%s %s you for %%d.",
    school = "%%s %s you for %%d %%s damage.", source = 1, target = SELF, amount = 2, schoolSlot = 3 },
  { suffix = "OTHEROTHER", plain = "%%s %s %%s for %%d.",
    school = "%%s %s %%s for %%d %%s damage.", source = 1, target = 2, amount = 3, schoolSlot = 4 }
}
for _, side in ipairs(sides) do
  local hit = side.source == SELF and "hit" or "hits"
  local crit = side.source == SELF and "crit" or "crits"
  define("melee", "COMBATHIT" .. side.suffix, string.format(side.plain, hit),
    side.source, nil, side.target, side.amount)
  define("melee", "COMBATHITCRIT" .. side.suffix, string.format(side.plain, crit),
    side.source, nil, side.target, side.amount, nil, true)
  define("melee", "COMBATHITSCHOOL" .. side.suffix, string.format(side.school, hit),
    side.source, nil, side.target, side.amount, side.schoolSlot)
  define("melee", "COMBATHITCRITSCHOOL" .. side.suffix, string.format(side.school, crit),
    side.source, nil, side.target, side.amount, side.schoolSlot, true)
end

local spellSides = {
  { suffix = "SELFSELF", text = "Your %%s %s you for %%d", source = SELF, spell = 1, target = SELF, amount = 2, school = 3 },
  { suffix = "SELFOTHER", text = "Your %%s %s %%s for %%d", source = SELF, spell = 1, target = 2, amount = 3, school = 4 },
  { suffix = "OTHERSELF", text = "%%s's %%s %s you for %%d", source = 1, spell = 2, target = SELF, amount = 3, school = 4 },
  { suffix = "OTHEROTHER", text = "%%s's %%s %s %%s for %%d", source = 1, spell = 2, target = 3, amount = 4, school = 5 }
}
for _, side in ipairs(spellSides) do
  define("spell", "SPELLLOG" .. side.suffix, string.format(side.text, "hits") .. ".",
    side.source, side.spell, side.target, side.amount)
  define("spell", "SPELLLOGCRIT" .. side.suffix, string.format(side.text, "crits") .. ".",
    side.source, side.spell, side.target, side.amount, nil, true)
  define("spell", "SPELLLOGSCHOOL" .. side.suffix, string.format(side.text, "hits") .. " %s damage.",
    side.source, side.spell, side.target, side.amount, side.school)
  define("spell", "SPELLLOGCRITSCHOOL" .. side.suffix, string.format(side.text, "crits") .. " %s damage.",
    side.source, side.spell, side.target, side.amount, side.school, true)
end

define("periodic", "PERIODICAURADAMAGESELFOTHER", "%s suffers %d %s damage from your %s.", SELF, 4, 1, 2, 3)
define("periodic", "PERIODICAURADAMAGEOTHEROTHER", "%s suffers %d %s damage from %s's %s.", 4, 5, 1, 2, 3)
define("periodic", "PERIODICAURADAMAGESELFSELF", "You suffer %d %s damage from your %s.", SELF, 3, SELF, 1, 2)
define("periodic", "PERIODICAURADAMAGEOTHERSELF", "You suffer %d %s damage from %s's %s.", 3, 4, SELF, 1, 2)
define("shield", "DAMAGESHIELDSELFOTHER", "You reflect %d %s damage to %s.", SELF, nil, 3, 1, 2)
define("shield", "DAMAGESHIELDOTHERSELF", "%s reflects %d %s damage to you.", 1, nil, SELF, 2, 3)
define("shield", "DAMAGESHIELDOTHEROTHER", "%s reflects %d %s damage to %s.", 1, nil, 4, 2, 3)

KM.combatEvents = {}
local function events(family, names)
  for _, name in ipairs(names) do KM.combatEvents[name] = family end
end
events("melee", {
  "CHAT_MSG_COMBAT_SELF_HITS", "CHAT_MSG_COMBAT_PET_HITS", "CHAT_MSG_COMBAT_PARTY_HITS",
  "CHAT_MSG_COMBAT_FRIENDLYPLAYER_HITS", "CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS",
  "CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS", "CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS",
  "CHAT_MSG_COMBAT_CREATURE_VS_CREATURE_HITS"
})
events("spell", {
  "CHAT_MSG_SPELL_SELF_DAMAGE", "CHAT_MSG_SPELL_PET_DAMAGE", "CHAT_MSG_SPELL_PARTY_DAMAGE",
  "CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE", "CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE",
  "CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE", "CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMAGE",
  "CHAT_MSG_SPELL_CREATURE_VS_CREATURE_DAMAGE"
})
events("periodic", {
  "CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE", "CHAT_MSG_SPELL_PERIODIC_PARTY_DAMAGE",
  "CHAT_MSG_SPELL_PERIODIC_FRIENDLYPLAYER_DAMAGE", "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE",
  "CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE"
})
events("shield", { "CHAT_MSG_SPELL_DAMAGESHIELDS_ON_SELF", "CHAT_MSG_SPELL_DAMAGESHIELDS_ON_OTHERS" })

-- Compile printf placeholders rather than hardcoding English regular expressions.
-- map[capture] = original printf slot, including positional forms such as %2$s.
function KM:CompileFormat(text)
  local pattern, map, cursor, nextSlot = "", {}, 1, 1
  while cursor <= string.len(text) do
    local char = string.sub(text, cursor, cursor)
    if char == "%" then
      local tail = string.sub(text, cursor)
      local _, finish, slot, kind = string.find(tail, "^%%(%d+)%$([sd])")
      if not finish then
        _, finish, kind = string.find(tail, "^%%([sd])")
        slot = nextSlot
        if finish then nextSlot = nextSlot + 1 end
      end
      if finish then
        table.insert(map, tonumber(slot))
        pattern = pattern .. (kind == "d" and "(%d+)" or "(.-)")
        cursor = cursor + finish
      elseif string.sub(tail, 1, 2) == "%%" then
        pattern = pattern .. "%%"
        cursor = cursor + 2
      else
        return nil -- Unsupported printf directives must not produce loose matches.
      end
    else
      if string.find("^$()%.[]*+-?", char, 1, true) then char = "%" .. char end
      pattern = pattern .. char
      cursor = cursor + 1
    end
  end
  return { pattern = pattern, map = map }
end

function KM:BuildParser()
  self.formats, self.trailers = {}, {}
  self.formatCount, self.fallbackCount = 0, 0
  self.locale = GetLocale and GetLocale() or "enUS"
  for family, entries in pairs(definitions) do
    self.formats[family] = {}
    for _, definition in ipairs(entries) do
      local text = getglobal(definition.key)
      local fallback = false
      if type(text) ~= "string" and self.locale == "enUS" then
        text, fallback = definition.english, true
      end
      if type(text) == "string" then
        local compiled = self:CompileFormat(text)
        if compiled then
          table.insert(self.formats[family], { definition = definition, compiled = compiled })
          self.formatCount = self.formatCount + 1
          if fallback then self.fallbackCount = self.fallbackCount + 1 end
        end
      end
    end
  end
  local trailers = {
    { "ABSORB_TRAILER", " (%d absorbed)" }, { "RESIST_TRAILER", " (%d resisted)" },
    { "BLOCK_TRAILER", " (%d blocked)" }, { "GLANCING_TRAILER", " (glancing)" },
    { "CRUSHING_TRAILER", " (crushing)" }
  }
  for _, trailer in ipairs(trailers) do
    local text = getglobal(trailer[1])
    if type(text) ~= "string" and self.locale == "enUS" then text = trailer[2] end
    if type(text) == "string" then
      local compiled = self:CompileFormat(text)
      if compiled then table.insert(self.trailers, compiled.pattern .. "$") end
    end
  end
end

function KM:CleanMessage(message)
  message = string.gsub(message, "|c%x%x%x%x%x%x%x%x", "")
  message = string.gsub(message, "|r", "")
  message = string.gsub(message, "|H.-|h%[(.-)%]|h", "%1")
  message = string.gsub(message, "|H.-|h(.-)|h", "%1")
  -- A hit can have more than one trailer, for example blocked and absorbed.
  for pass = 1, 6 do
    local before = message
    for _, pattern in ipairs(self.trailers) do message = string.gsub(message, pattern, "") end
    if message == before then break end
  end
  return message
end

function KM:Parse(combatEvent, message)
  local family = self.combatEvents[combatEvent]
  if not family or type(message) ~= "string" then return nil end
  local clean = self:CleanMessage(message)
  for _, format in ipairs(self.formats[family]) do
    local compiled, definition = format.compiled, format.definition
    local first, last, a, b, c, d, e = string.find(clean, "^" .. compiled.pattern .. "$")
    if first then
      local captures, slots = { a, b, c, d, e }, {}
      for index, slot in ipairs(compiled.map) do slots[slot] = captures[index] end
      local player = UnitName("player")
      local school = definition.school and slots[definition.school] or "Physical"
      local ability = definition.spell and slots[definition.spell] or "Melee"
      if family == "shield" then ability = "Damage shield (" .. school .. ")" end
      return {
        source = definition.source == SELF and player or slots[definition.source],
        target = definition.target == SELF and player or slots[definition.target],
        spell = ability, amount = tonumber(slots[definition.amount]),
        school = school, critical = definition.crit and true or false
      }
    end
  end
  return nil
end
