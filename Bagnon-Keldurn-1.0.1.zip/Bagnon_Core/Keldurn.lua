-- Inventory changes may arrive before slot data, or without BAG_UPDATE.
-- Keep native item operations; reconcile only visible, live inventory windows.
local due, nextPoll = nil, 0;
local layouts, states, active = {}, {}, {};

function BagnonKeldurn_RequestRefresh()
	if not due then due = GetTime() + 0.05; end
end

local function RefreshWindow(frame, force)
	if not frame then return; end
	if not frame:IsVisible() or not frame.size or Bagnon_IsCachedFrame(frame) then active[frame] = nil; return; end
	force = force or not active[frame];
	active[frame] = true;
	local name = frame:GetName();
	local settings = BagnonSets and BagnonSets[name];
	if not settings or not settings.bags then return; end
	local layout = "";
	for _, bag in ipairs(settings.bags) do
		local size;
		if bag == KEYRING_CONTAINER then size = GetKeyRingSize(); else size = GetContainerNumSlots(bag); end
		layout = layout .. tostring(bag) .. ":" .. tostring(size) .. ";";
	end
	if layouts[frame] and layouts[frame] ~= layout then
		BagnonFrame_Generate(frame);
		force = true;
	end
	layouts[frame] = layout;
	for slot = 1, frame.size do
		local item = getglobal(name .. "Item" .. slot);
		if item and not Bagnon_IsCachedItem(item) then
			local bag, index = item:GetParent():GetID(), item:GetID();
			local texture, count, locked, quality, readable = GetContainerItemInfo(bag, index);
			local link = GetContainerItemLink(bag, index);
			local start, duration, enable = GetContainerItemCooldown(bag, index);
			local old = states[item];
			if force or not old or old[1] ~= bag or old[2] ~= index or old[3] ~= texture or old[4] ~= count or old[5] ~= locked or old[6] ~= quality or old[7] ~= readable or old[8] ~= link or old[9] ~= start or old[10] ~= duration or old[11] ~= enable then
				BagnonItem_Update(item);
				states[item] = {bag, index, texture, count, locked, quality, readable, link, start, duration, enable};
			end
		end
	end
end

local watcher = CreateFrame("Frame");
for _, name in ipairs({"BAG_UPDATE", "BAG_UPDATE_COOLDOWN", "ITEM_LOCK_CHANGED", "CURSOR_UPDATE", "PLAYERBANKSLOTS_CHANGED", "PLAYERBANKBAGSLOTS_CHANGED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED", "PLAYER_ENTERING_WORLD"}) do
	watcher:RegisterEvent(name);
end
watcher:SetScript("OnEvent", BagnonKeldurn_RequestRefresh);
watcher:SetScript("OnUpdate", function()
	local now = GetTime();
	local force = due and now >= due;
	if not force and now < nextPoll then return; end
	if force then due = nil; end
	nextPoll = now + 0.2;
	RefreshWindow(Bagnon, force);
	RefreshWindow(Banknon, force);
end);
watcher:Show();
