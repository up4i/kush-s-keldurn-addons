# Bagnon for Keldurn — rewritten compatibility edition

Original addon by Tuller. Retains native item operations and saved settings.

## Install

Close Keldurn. Press **Win + R** and open `%LOCALAPPDATA%\Keldurn\settings\AddOns`.
Extract this ZIP there, replacing **both Bagnon and Bagnon_Core** folders. Keep one copy of each and preserve saved variables. Launch Keldurn and enable both addons at character selection. Alternatively use **Install ZIP** in the character selection AddOns menu.

## Fixes

Explicitly hides empty-slot icons and clears old counts. Coalesces events into a delayed refresh of both live windows. Checks visible inventory every 0.2 seconds for missing or early events; unchanged slots are not repainted. Rebuilds layouts when per-bag capacity changes. Skips hidden windows and cached/offline inventory.

## Validation

Lua 5.0 tests simulate same-bag/cross-bag moves, missing/early events, stack counts, locks, event coalescing, hidden/cached windows and bag size changes. In-game testing is still needed. This patch fixes display refreshes; it does not modify server inventory.
