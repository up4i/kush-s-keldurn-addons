local clock, reads, updates, generates = 0, 0, 0, 0
local slots = {}
local sizes = {[0]=2,[1]=2}
local function region() return {Show=function(s)s.visible=true end,Hide=function(s)s.visible=false end,SetTexture=function(s,t)s.texture=t end,SetText=function(s,t)s.text=t end} end
function getglobal(n) return _G[n] end
function GetTime() return clock end
function CreateFrame() local f={}; function f:RegisterEvent()end;function f:SetScript(n,s)self[n]=s end;function f:Show()end; watcher=f;return f end
function GetContainerNumSlots(b)return sizes[b] end
function GetKeyRingSize()return 0 end
KEYRING_CONTAINER=-2
function GetContainerItemInfo(b,i) reads=reads+1;local s=slots[b..':'..i] or {};return s[1],s[2],s[3],s[4],s[5] end
function GetContainerItemLink(b,i)return (slots[b..':'..i] or {})[6] end
function GetContainerItemCooldown()return 0,0,1 end
function Bagnon_IsCachedFrame(f)return f.cached end
function Bagnon_IsCachedItem(i)return i:GetParent():GetParent().cached end
function SetItemButtonTexture()end -- deliberately reproduce a helper that leaves old images
function SetItemButtonCount()end
function SetItemButtonDesaturated(i,l)i.locked=l end
function CooldownFrame_SetTimer()end
BagnonSets={Bagnon={bags={0,1}},Banknon={bags={0,1}}}
local function frame(name)
 local f={size=4,visible=true};function f:GetName()return name end;function f:IsVisible()return self.visible end
 for n=1,4 do
  local bag={id=math.floor((n-1)/2)};function bag:GetID()return self.id end;function bag:GetParent()return f end
  local item={id=math.mod(n-1,2)+1};local iname=name..'Item'..n
  function item:GetName()return iname end;function item:GetID()return self.id end;function item:GetParent()return bag end
  _G[iname]=item;for _,suffix in ipairs({'IconTexture','Count','Cooldown'})do _G[iname..suffix]=region()end
 end
 return f
end
Bagnon=frame('Bagnon');Banknon=frame('Banknon')
function BagnonFrame_Generate(f)generates=generates+1 end
assert(loadfile('core/Item.lua'))()
function BagnonItem_UpdateBorder()end
function BagnonItem_UpdateLinkBorder()end
local actual=BagnonItem_Update
function BagnonItem_Update(i)updates=updates+1;actual(i)end
assert(loadfile('Keldurn.lua'))()
local function tick(t)clock=clock+t;watcher.OnUpdate()end
local function icon(n)return _G['BagnonItem'..n..'IconTexture']end
slots['0:1']={'apple',3,false,nil,false,'apple-link'};tick(.21)
assert(icon(1).visible and BagnonItem1Count.text==3)
slots['0:1']=nil;slots['0:2']={'apple',1};watcher.OnEvent();tick(.06)
assert(not icon(1).visible and not BagnonItem1Count.visible and BagnonItem1Count.text=='')
assert(icon(2).visible and not BagnonItem2Count.visible)
slots['0:2']=nil;slots['1:1']={'apple',7};watcher.OnEvent();tick(.06)
assert(not icon(2).visible and icon(3).visible and BagnonItem3Count.text==7)
slots['1:1']=nil;slots['1:2']={'pear',2};tick(.21) -- no event fallback
assert(not icon(3).visible and icon(4).texture=='pear')
watcher.OnEvent();tick(.06);slots['1:2']={'pear',5,true};tick(.21) -- data arrives after event
assert(BagnonItem4Count.text==5 and BagnonItem4.locked)
slots['1:2']={'pear',1,false};tick(.21);assert(not BagnonItem4Count.visible and not BagnonItem4.locked)
local before=updates;tick(.21);assert(updates==before) -- unchanged slots do not repaint
for i=1,100 do watcher.OnEvent()end;tick(.06);assert(updates==before+8) -- both windows once
Banknon.cached=true;local old=BanknonItem4IconTexture.texture;slots['1:2']={'banana',1};tick(.21);assert(BanknonItem4IconTexture.texture==old)
Bagnon.visible=false;before=reads;tick(.21);assert(reads==before) -- hidden/cached windows do no inventory work
Bagnon.visible=true;tick(.21);sizes[0]=3;sizes[1]=1;tick(.21);assert(generates==1) -- same total, different bag layout
print('PASS: moves, missing/early events, counts, locks, coalescing, cached/hidden windows, bag sizes')
