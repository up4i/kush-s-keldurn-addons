-- Run from Gatherer with Lua 5.0.
function UnitName()return 'Tester' end
GetUnitName=nil
StaticPopupDialogs={};function TEXT(v)return v end
assert(loadfile('Gatherer.lua'))()
assert(loadfile('GatherBroadcast.lua'))()
local draw,updates,sends=0,0,0
function Gatherer_PlayerPos()return .25,.5 end
function Gatherer_GetCurrentZone()return 1,2 end
function Gatherer_Distance(x,y,a,b)return math.sqrt((x-a)^2+(y-b)^2) end
function Gatherer_GetDB_IconIndex(icon)return icon end
function Gatherer_OnUpdate()updates=updates+1 end
function GatherMain_Draw()draw=draw+1 end
function Gatherer_ChatPrint()end
Gatherer_Settings={filterRecording={},interested={},debug=false}
function IsInGuild()return true end
local herbs={'Steelbloom','Kingsblood','Briarthorn','Bruiseweed'}
-- Missing send API must not prevent any local records or UI updates.
SendAddonMessage=nil
for _,herb in ipairs(herbs)do
 Gatherer_AddGatherHere(herb,1,herb,0)
 local node=GatherItems[1][2][herb][1]
 assert(node and node.count==1 and node.x==25 and node.y==50)
end
assert(draw==4 and updates==4)
-- Transport exceptions are isolated; repeated collection increments the database.
function SendAddonMessage()error('transport unavailable')end
Gatherer_AddGatherHere('Kingsblood',1,'Kingsblood',0)
assert(GatherItems[1][2].Kingsblood[1].count==2 and draw==5)
-- Successful sends happen after the record and map refresh.
function SendAddonMessage(prefix,message,channel)
 sends=sends+1
 assert(prefix=='GATHERER' and channel=='GUILD' and draw==6)
 assert(GatherItems[1][2].Kingsblood[1].count==3)
 local sender,name,kind,c,z,x,y,icon,event=Gatherer_DecodeGather(message)
 assert(sender=='Tester' and name=='Kingsblood' and kind==1 and c==1 and z==2 and x==25 and y==50 and event==0)
end
Gatherer_AddGatherHere('Kingsblood',1,'Kingsblood',0);assert(sends==1)
-- Own broadcasts are ignored; other players' broadcasts record without counting as personal gathers.
local message=Gatherer_EncodeGather('Tester','Kingsblood',1,1,2,25,50,'Kingsblood',0)
Gatherer_ReceiveBroadcast(message);assert(GatherItems[1][2].Kingsblood[1].count==3)
message=Gatherer_EncodeGather('Friend','Briarthorn',1,1,2,80,80,'Briarthorn',0)
Gatherer_AddonMessageEvent('GATHERER',message,'GUILD')
assert(GatherItems[1][2].Briarthorn[2].x==80 and GatherItems[1][2].Briarthorn[2].count==0)
function IsInGuild()return false end
Gatherer_AddGatherHere('Bruiseweed',1,'Bruiseweed',0);assert(sends==1)
-- Recording filters still apply.
Gatherer_Settings.filterRecording[1]=true;Gatherer_Settings.interested[1]={Kingsblood=true}
Gatherer_AddGatherHere('Peacebloom',1,'Peacebloom',0);assert(not GatherItems[1][2].Peacebloom)
print('PASS: four reported herbs, recording/counts, refreshes, missing/failing/successful sends, self/remote broadcasts, guildless players and filters')
