# Gatherer for Keldurn — 2.99.1-Keldurn.2

Based on Gatherer 2.99.1. Retains the previous Hide Icon checkbox syntax fix.

## Recording fix

Replaces the unavailable GetUnitName call with the vanilla UnitName API in both outgoing and incoming broadcasts. Saves and refreshes local nodes before optional guild sharing. Missing addon-message APIs, guildless characters, and send failures no longer interrupt local recording.

## Install

Close Keldurn. Press Win + R and open `%LOCALAPPDATA%\Keldurn\settings\AddOns`. Extract this ZIP and replace the existing Gatherer folder. Keep one installed copy and preserve saved variables for recorded nodes and settings. Restart and enable Gatherer at character selection. Install ZIP is also available there.

## Validation

Lua 5.0 tests run the actual recording and broadcast functions for Steelbloom, Kingsblood, Briarthorn, and Bruiseweed. They check saved coordinates, repeated gather counts, UI refreshes, missing/failing/successful sends, guildless characters, self/remote messages, and filters. All Lua files and 279 embedded XML handlers compile. Live Keldurn testing remains necessary.
