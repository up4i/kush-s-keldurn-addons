-- Keldurn can update native cooldowns without calling CooldownFrame_SetTimer.
-- Read authoritative cooldowns only for visible buttons, without changing models.
local elapsed = 0;
local function UpdateButton(button, cooldown, start, duration, enabled)
	if not cooldown then return; end
	start, duration = tonumber(start) or 0, tonumber(duration) or 0;
	if duration > OmniCC.min and enabled ~= 0 and enabled ~= false and start + duration > GetTime() then
		local text = cooldown.textFrame;
		if not text or text.start ~= start or text.duration ~= duration or not text:IsShown() then
			-- Use the original text constructor, while suppressing the native timer call.
			OmniCC_KeldurnSetText(cooldown, start, duration, enabled);
		end
	elseif cooldown.textFrame then
		cooldown.textFrame:Hide();
	end
end

local function ReadButton(name, kind, index)
	local button = getglobal(name);
	if not button or not button:IsVisible() then return; end
	local cooldown = getglobal(name .. "Cooldown") or button.cooldown;
	if not cooldown then return; end
	local start, duration, enabled;
	if kind == "pet" then
		start, duration, enabled = GetPetActionCooldown(index);
	elseif kind == "stance" then
		start, duration, enabled = GetShapeshiftFormCooldown(index);
	elseif kind == "bag" then
		start, duration, enabled = GetContainerItemCooldown(button:GetParent():GetID(), button:GetID());
	else
		local action = button.action;
		if not action and kind == "main" then
			if ActionButton_GetPagedID then action = ActionButton_GetPagedID(button);
			elseif GetBonusBarOffset and GetBonusBarOffset() > 0 then action = index + (GetBonusBarOffset() + 6) * 12;
			else action = index + ((GetActionBarPage and GetActionBarPage() or 1) - 1) * 12; end
		end
		start, duration, enabled = GetActionCooldown(action or index);
	end
	UpdateButton(button, cooldown, start, duration, enabled);
end

local watcher = CreateFrame("Frame");
watcher:SetScript("OnUpdate", function(frame, delta)
	elapsed = elapsed + (delta or arg1 or 0);
	if elapsed < 0.1 then return; end
	elapsed = 0;
	for i = 1, 12 do
		ReadButton("ActionButton" .. i, "main", i);
		ReadButton("BonusActionButton" .. i, "main", i);
		ReadButton("MultiBarBottomLeftButton" .. i, "action", i + 60);
		ReadButton("MultiBarBottomRightButton" .. i, "action", i + 48);
		ReadButton("MultiBarRightButton" .. i, "action", i + 24);
		ReadButton("MultiBarLeftButton" .. i, "action", i + 36);
	end
	for i = 1, 10 do
		ReadButton("PetActionButton" .. i, "pet", i);
		ReadButton("ShapeshiftButton" .. i, "stance", i);
	end
	for bag = 1, 13 do
		local container = getglobal("ContainerFrame" .. bag);
		if container and container:IsVisible() then
			for i = 1, GetContainerNumSlots(container:GetID()) do ReadButton("ContainerFrame" .. bag .. "Item" .. i, "bag", i); end
		end
	end
	for _, name in ipairs({"Bagnon", "Banknon"}) do
		local window = getglobal(name);
		if window and window:IsVisible() and not (Bagnon_IsCachedFrame and Bagnon_IsCachedFrame(window)) then
			for i = 1, window.size or 0 do ReadButton(name .. "Item" .. i, "bag", i); end
		end
	end
end);
watcher:Show();
