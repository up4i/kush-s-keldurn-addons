-- Run from !OmniCC with Lua 5.0 or 5.1.
local now, nativeCalls, reads = 100, 0, 0
local frames = {}
SlashCmdList = {}
DEFAULT_CHAT_FRAME = {AddMessage=function()end}
DAY_ONELETTER_ABBR='d';HOUR_ONELETTER_ABBR='%d h';MINUTE_ONELETTER_ABBR='m'
function GetTime()return now end
function getglobal(n)return _G[n]end
local methods={}
function methods:GetParent()return self.parent end
function methods:GetName()return self.name end
function methods:GetID()return self.id or 1 end
function methods:IsShown()return self.shown end
function methods:IsVisible()return self.shown and (not self.parent or self.parent:IsVisible())end
function methods:Show()self.shown=true end
function methods:Hide()self.shown=false end
function methods:GetFrameLevel()return self.level end
function methods:SetFrameLevel(v)self.level=v end
function methods:GetAlpha()return 1 end
function methods:SetAlpha()end
function methods:SetAllPoints()end
function methods:SetPoint()end
function methods:SetScript(n,f)self[n]=f end
function methods:SetFont(font,size)self.font=font;self.size=size;return font~='bad' end
function methods:SetText(t)self.textValue=t end
function methods:SetTextColor()end
function methods:CreateFontString()return CreateFrame('FontString',nil,self)end
function CreateFrame(kind,name,parent)
 local f={name=name,parent=parent,shown=true,level=4}
 setmetatable(f,{__index=methods});table.insert(frames,f)
 if name then _G[name]=f end
 return f
end
function CooldownFrame_SetTimer()nativeCalls=nativeCalls+1 end
local data={ [1]={100,10,1},[13]={100,20,1},[61]={100,30,1} }
function GetActionCooldown(i)reads=reads+1;return unpack(data[i] or {0,0,0})end
function ActionButton_GetPagedID(b)return (b:GetID() or 1)+12 end
function GetPetActionCooldown()return 100,15,1 end
function GetShapeshiftFormCooldown()return 100,8,1 end
function GetContainerItemCooldown()return 100,9,1 end
function GetContainerNumSlots()return 1 end
local button=CreateFrame('Button','ActionButton1');button.id=1
local cd=CreateFrame('Cooldown','ActionButton1Cooldown',button)
local extra=CreateFrame('Button','MultiBarBottomLeftButton1')
local extraCD=CreateFrame('Cooldown','MultiBarBottomLeftButton1Cooldown',extra)
local pet=CreateFrame('Button','PetActionButton1');CreateFrame('Cooldown','PetActionButton1Cooldown',pet)
local stance=CreateFrame('Button','ShapeshiftButton1');CreateFrame('Cooldown','ShapeshiftButton1Cooldown',stance)
assert(loadfile('OmniCC.lua'))();assert(loadfile('Keldurn.lua'))()
assert(SLASH_OMNICCCOMMAND1=='/omnicc' and SLASH_OMNICCCOMMAND2=='/omni' and SLASH_OMNICCCOMMAND3=='/cc')
assert(SlashCmdList.OMNICCCOMMAND)
SlashCmdList.OMNICCCOMMAND('');SlashCmdList.OMNICCCOMMAND('size 24');assert(OmniCC.size==24)
SlashCmdList.OMNICCCOMMAND('min -10');assert(OmniCC.min==0);SlashCmdList.OMNICCCOMMAND('reset')
SlashCmdList.OMNICCCOMMAND('font bad');assert(OmniCC.font~='bad')
CooldownFrame_SetTimer(cd,100,10,1);assert(nativeCalls==1 and cd.textFrame:IsShown() and cd.textFrame.text.textValue==10)
now=106;cd.textFrame.OnUpdate(cd.textFrame,.2);cd.textFrame.OnUpdate(cd.textFrame,.2)
assert(cd.textFrame.text.textValue==4)
-- Legacy callback globals remain supported.
this=cd.textFrame;arg1=.2;now=111;OmniCC_OnUpdate();OmniCC_OnUpdate();assert(not cd.textFrame:IsShown())
-- Native cooldown fallback does not call the legacy setter or change the model.
now=100
local watcher
for _,f in ipairs(frames)do if f.OnUpdate and f~=cd.textFrame then watcher=f end end
assert(watcher)
watcher.OnUpdate(watcher,.11)
assert(nativeCalls==1 and cd.textFrame.duration==20 and extraCD.textFrame.duration==30)
assert(PetActionButton1Cooldown.textFrame:IsShown() and ShapeshiftButton1Cooldown.textFrame:IsShown())
local bag=CreateFrame('Frame','ContainerFrame1');bag.id=0
local item=CreateFrame('Button','ContainerFrame1Item1',bag)
CreateFrame('Cooldown','ContainerFrame1Item1Cooldown',item)
local inventory=CreateFrame('Frame','Bagnon');inventory.size=1
local dummy=CreateFrame('Frame',nil,inventory);dummy.id=0
local bitem=CreateFrame('Button','BagnonItem1',dummy)
CreateFrame('Cooldown','BagnonItem1Cooldown',bitem)
local cached=false
function Bagnon_IsCachedFrame()return cached end
watcher.OnUpdate(watcher,.11)
assert(ContainerFrame1Item1Cooldown.textFrame:IsShown() and BagnonItem1Cooldown.textFrame:IsShown())
cached=true;BagnonItem1Cooldown.textFrame:Hide();watcher.OnUpdate(watcher,.11);assert(not BagnonItem1Cooldown.textFrame:IsShown())
local oldreads=reads;watcher.OnUpdate(watcher,.01);assert(reads==oldreads)
data[13]={100,1.5,1};watcher.OnUpdate(watcher,.11);assert(not cd.textFrame:IsShown())
data[13]={100,20,0};watcher.OnUpdate(watcher,.11);assert(not cd.textFrame:IsShown())
data[13]={100,20,1};watcher.OnUpdate(watcher,.11);assert(cd.textFrame:IsShown())
button:Hide();extra:Hide();oldreads=reads;watcher.OnUpdate(watcher,.11);assert(reads==oldreads)
button:Show();now=121;watcher.OnUpdate(watcher,.11);assert(not cd.textFrame:IsShown())
local unnamed=CreateFrame('Button');local unnamedCD=CreateFrame('Cooldown',nil,unnamed)
now=1;CooldownFrame_SetTimer(unnamedCD,0,10,1);assert(unnamedCD.textFrame:IsShown())
CooldownFrame_SetTimer(unnamedCD,0,0,0);assert(not unnamedCD.textFrame:IsShown())
now=100;CooldownFrame_SetTimer(cd,100,3600,1);assert(cd.textFrame.text.textValue=='1 h')
MINUTE_ONELETTER_ABBR='%d m';CooldownFrame_SetTimer(cd,100,120,1);assert(cd.textFrame.text.textValue=='2 m')
print('PASS: aliases, settings, font fallback, modern/legacy callbacks, expiry, native fallback, pages, extra/pet/stance buttons, GCD/disabled filters, throttle, hidden buttons, unnamed buttons and time abbreviations')
