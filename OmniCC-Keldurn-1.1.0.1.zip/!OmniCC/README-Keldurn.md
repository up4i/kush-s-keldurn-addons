# OmniCC for Keldurn

Adapted from Tuller's Omni Cooldown Count 1.1.0. Displays remaining cooldown time over buttons.

## Install

Close Keldurn. Press Win + R and open `%LOCALAPPDATA%\Keldurn\settings\AddOns`.
Extract the included **!OmniCC** folder directly into AddOns, replacing the existing !OmniCC folder. Keep the exclamation mark and remove duplicate installations. Preserve saved variables. Restart Keldurn and enable Omni Cooldown Count at character selection. Install ZIP is also available there.

## Commands

`/omnicc`, `/omni`, and `/cc` are aliases. These are chat commands, not a graphical settings window.

- `/cc` — print help.
- `/cc size 24` — change text size (default 20).
- `/cc min 3` — show text for cooldowns longer than three seconds (default); ordinary global cooldowns are filtered out.
- `/cc color short 1 0 0` — change short-duration text color. Also supports medium and long; color values range from 0 to 1.
- `/cc font Fonts\FRIZQT__.TTF` — select a font.
- `/cc reset` — restore default settings.

## Compatibility changes

Updates the interface version to 11200, registers uppercase slash-command identifiers and three aliases, accepts both legacy and frame-argument update callbacks, and uses FontStrings without requiring CreateFont. Countdown text sits above cooldown frames; zero-start timers and time abbreviations are supported.

Retains the existing CooldownFrame_SetTimer hook and adds a 0.1-second fallback for visible action, bonus, multibar, pet, stance, standard bag and Bagnon/Banknon item buttons. The fallback reads native cooldown APIs and does not restart their cooldown models. Other custom frames continue to work when they call the shared timer hook.

## Validation

Lua 5.0 tests simulate alias registration, settings, font fallback, callback styles, countdown expiry, action pages, pets, stances, bag items, cached inventory, short/disabled cooldowns, throttling, hidden/unnamed buttons and time abbreviations. Live Keldurn testing is still needed.
