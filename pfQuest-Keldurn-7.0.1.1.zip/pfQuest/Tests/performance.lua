-- Run from the pfQuest folder: lua Tests/performance.lua
dofile("minimap-index.lua")
local nodes = { PFQUEST = { [1] = {} }, OTHER = { [1] = {}, [2] = {} } }
for x=1,100 do
  for y=1,100 do nodes.PFQUEST[1][x.."|"..y] = { id = x..":"..y } end
end
nodes.OTHER[1]["50.5|49.5"] = { id = "fractional" }
nodes.OTHER[2]["50|50"] = { id = "other-zone" }
local index = pfQuestMinimapIndex.Build(nodes, 1)
assert(index.count == 10001)
local near = pfQuestMinimapIndex.Nearby(index, 45, 55, 45, 55)
assert(table.getn(near) == 122)
assert(table.getn(near) < index.count / 50)
math.randomseed(12)
for query=1,100 do
  local xmin, ymin = math.random(-5,105), math.random(-5,105)
  local xmax, ymax = xmin + math.random(0,12), ymin + math.random(0,12)
  local expected, actual = {}, {}
  for addon, maps in pairs(nodes) do
    for coord, node in pairs(maps[1] or {}) do
      local _, _, sx, sy = string.find(coord, "^([^|]+)|([^|]+)$")
      local x, y = tonumber(sx), tonumber(sy)
      if x >= xmin and x <= xmax and y >= ymin and y <= ymax then expected[node.id] = true end
    end
  end
  for _, entry in ipairs(pfQuestMinimapIndex.Nearby(index, xmin,xmax,ymin,ymax)) do
    assert(not actual[entry.node.id], "duplicate indexed marker")
    actual[entry.node.id] = true
  end
  for id in pairs(expected) do assert(actual[id], "marker missing from index: "..id) end
  for id in pairs(actual) do assert(expected[id], "unexpected marker: "..id) end
end

-- Execute the actual minimap refresh function with simulated native frames.
local function source(path)
  local f = assert(io.open(path)); local text = f:read("*a"); f:close(); return text
end
local map = source("map.lua")
local start = assert(string.find(map, "function pfMap:UpdateMinimap()", 1, true))
local finish = assert(string.find(map, "local zone, last_zone", start, true))
local frame = {}
frame.__index = frame
function frame:Hide() self.visible = false end
function frame:Show() self.visible = true end
function frame:ClearAllPoints() end
function frame:SetPoint(_,_,_,x,y) self.x,self.y = x,y end
local px, py, clock = .5, .5, 2
function GetPlayerMapPosition() return px, py end
function GetTime() return clock end
function GetRealZoneText() return "Test Zone" end
function MouseIsOver() return false end
pfQuest_config = { minimapnodes = "1", spawncolors = "0", showclustermini = "1", showspawnmini = "1" }
pfQuestCompat = {}
pfUI = {}
controlkey = {}
nodename = "pfQuestTestNode"
minimap_zoom = { [1] = { [0] = 100 } }
minimap_sizes = { [1] = {1000,1000} }
function minimap_indoor() return 1 end
sqrt = math.sqrt
abs = math.abs
pfMap = { nodes = nodes, mpins = {}, drawlayer = {} }
function pfMap.drawlayer:GetZoom() return 0 end
function pfMap.drawlayer:GetWidth() return 200 end
function pfMap.drawlayer:GetHeight() return 200 end
function pfMap:GetMapIDByName() return 1 end
function pfMap:HasMinimap() return true end
function pfMap:BuildNode() return setmetatable({hl = setmetatable({},frame)}, frame) end
function pfMap:UpdateNode(pin,node) pin.node = node end
assert(loadstring(string.sub(map,start,finish-1)))()
this = pfMap
pfMap:UpdateMinimap()
local function visibleCount()
  local count = 0
  for _, pin in ipairs(pfMap.mpins) do if pin.visible then count = count + 1 end end
  return count
end
local expected = 0
for _, entry in ipairs(near) do
  if math.sqrt((entry.x-50)^2+(entry.y-50)^2)*20+8 < 100 then expected = expected + 1 end
end
assert(visibleCount() == expected, "indexed minimap differs from full scan")
local cached = pfMap.minimapIndex
px, py, clock = .55, .55, 2.3
pfMap:UpdateMinimap()
assert(pfMap.minimapIndex == cached, "movement rebuilt the spatial index")
assert(visibleCount() > 0, "movement lost minimap markers")
px, py, clock = 0,0,2.6
pfMap:UpdateMinimap()
assert(visibleCount() == 0, "invalid map left old pins visible")
nodes.PFQUEST[1] = {}
pfMap.minimapIndex = nil
px, py, clock = .5,.5,3
pfMap:UpdateMinimap()
assert(pfMap.minimapIndex.count == 1, "node removal did not refresh the index")
assert(visibleCount() == 1, "quest change left stale pins")

-- Execute the actual route callback and count its distance/line work.
local route = source("route.lua")
local mark = 'pfQuest.route:SetScript("OnUpdate", function()'
start = assert(string.find(route, mark, 1, true)) + string.len(mark)
finish = assert(string.find(route, 'end)\n\npfQuest.route.drawlayer', start, true))
local update = assert(loadstring("return function()"..string.sub(route,start,finish-1).."end"))()
local draws, clears, reads = 0,0,0
function ClearPath() clears = clears + 1 end
function DrawLine() draws = draws + 1 end
function GetPlayerMapPosition() reads = reads + 1 return .5,.5 end
ceil = math.ceil
objectivepath, playerpath, mplayerpath = {},{},{}
lastpos, completed = 0,0
pfQuest = {route = {IsTarget = function() return false end}}
WorldMapFrame = {IsShown = function() return false end}
pfQuest_config.routes = "1"
pfQuest_config.arrow = "0"
pfQuest_config.routeminimap = "0"
this = { coords = {{51,51,{}}}, arrow = {IsShown = function() return false end}, firstnode = "5151" }
clock = 4
update()
assert(draws == 0, "world route redrawn while the map is closed")
for tick=1,10 do clock = 4 + tick*.01 update() end
assert(draws == 0 and this.throttle == 4.25, "route throttle bypassed")
WorldMapFrame.IsShown = function() return true end
clock = 5.2
update()
assert(draws == 1, "opening the map failed to restore the route line")
pfQuest_config.routes = "0"
local before = reads
update(); update(); update()
assert(reads == before, "disabled route kept querying position")
pfQuest_config.routes = "1"
this = { coords = {}, arrow = {IsShown = function() return false end} }
for i=1,100 do this.coords[i] = {50+i*.01,51,{}} end
sortfunc = function(a,b) return a[4] < b[4] end
local planned = 0
function GetNearest(_,_,candidates,blacklist)
  assert(table.getn(candidates) <= 32, "route planning exceeded preview budget")
  planned = planned + 1
  for i, candidate in ipairs(candidates) do
    if not blacklist[i] then blacklist[i] = true return candidate end
  end
end
clock = 8
update()
assert(planned == 31, "route preview did not plan its 32 stops")
assert(table.getn(this.coords) == 100 and this.coords[100][4], "preview removed distant objectives")
print("PASS: 100 indexed/full-scan comparisons; actual minimap movement, invalidation and stale-pin cleanup; actual route scheduling and visibility.")
print("Representative query: 122 candidates instead of 10,001 zone markers (candidate count, not an in-game FPS benchmark).")
