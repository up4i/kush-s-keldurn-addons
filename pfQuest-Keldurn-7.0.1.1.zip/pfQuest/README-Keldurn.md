# pfQuest for Keldurn — movement performance patch

Version: **7.0.1-Keldurn.1**. Based on Shagu's pfQuest 7.0.1; original credits, licence, databases, and translations are retained.

## Install

Close Keldurn and replace the existing `pfQuest` addon folder with the folder from this ZIP. The location is `%LOCALAPPDATA%\Keldurn\settings\AddOns`. Keep your saved settings. Restart Keldurn and enable pfQuest on the character screen. You can also use **AddOns → Install ZIP** there.

## What changed

- Minimap markers use a cached spatial index, so moving scans nearby markers instead of every marker in the zone. The index is rebuilt after quest/map data changes.
- Minimap refreshes run at most five times per second; moving route updates run at most four times per second. Stationary updates retain the original slower refresh behavior.
- The arrow updates at 20 Hz instead of on every rendered frame.
- Player route lines are not redrawn on a closed world map. Empty or disabled routes stop doing repeated work.
- Route-line previews are limited to the nearest 32 stops. All quest markers, quest data, and nearest-target tracking remain available; the preview updates as you move. This bounds the original quadratic route-planning work.
- `/pfquest perf` reports FPS, zone markers, and nearby candidates for troubleshooting.

Original commands such as `/pfquest config` remain available.

## Check in game

Run through the same area that previously dropped to 10 FPS. If it still slows down, send `/pfquest perf` output while moving and say whether the world map, arrow, or minimap route lines are visible.

Offline checks verify marker selection and update behavior. This build has not been benchmarked inside a running Keldurn client, so an actual FPS gain still needs confirmation.
