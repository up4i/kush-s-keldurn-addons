-- Spatial index for minimap candidates. Coordinates are percentages (0..100).
-- Rebuilt when quest/map nodes change, rather than rescanning a whole zone
-- on every player-position update.
pfQuestMinimapIndex = {}

function pfQuestMinimapIndex.Build(nodes, mapID)
  local index = { cells = {}, count = 0 }
  for addon, maps in pairs(nodes) do
    for coords, node in pairs(maps[mapID] or {}) do
      local _, _, sx, sy = string.find(coords, "^([^|]+)|([^|]+)$")
      local x, y = tonumber(sx), tonumber(sy)
      if x and y then
        local bx, by = math.floor(x / 2), math.floor(y / 2)
        index.cells[bx] = index.cells[bx] or {}
        index.cells[bx][by] = index.cells[bx][by] or {}
        table.insert(index.cells[bx][by], { addon = addon, node = node, x = x, y = y })
        index.count = index.count + 1
      end
    end
  end
  return index
end

function pfQuestMinimapIndex.Nearby(index, xmin, xmax, ymin, ymax)
  local nearby = {}
  for bx=math.floor(xmin / 2),math.floor(xmax / 2) do
    local column = index.cells[bx]
    if column then
      for by=math.floor(ymin / 2),math.floor(ymax / 2) do
        for _, entry in ipairs(column[by] or {}) do
          if entry.x >= xmin and entry.x <= xmax and entry.y >= ymin and entry.y <= ymax then
            table.insert(nearby, entry)
          end
        end
      end
    end
  end
  return nearby
end
